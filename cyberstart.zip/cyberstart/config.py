import os
import re
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()

_CHANNEL_RE = re.compile(r"^@[A-Za-z][A-Za-z0-9_]{3,31}$")


@dataclass(frozen=True)
class Settings:
    bot_token: str
    admin_ids: frozenset[int]
    db_path: str
    required_channels: tuple[str, ...] = ()  # bo'sh bo'lsa, majburiy obuna o'chiq
    webapp_url: str | None = None            # bo'sh bo'lsa, Web App o'chiq
    webapp_host: str = "127.0.0.1"
    webapp_port: int = 8080


def _parse_admin_ids(raw: str) -> frozenset[int]:
    try:
        return frozenset(int(x) for x in raw.split(",") if x.strip())
    except ValueError:
        raise RuntimeError("ADMIN_IDS faqat vergul bilan ajratilgan raqamlar bo'lsin")


def _parse_channels(raw: str) -> tuple[str, ...]:
    channels = tuple(x.strip() for x in raw.split(",") if x.strip())
    for channel in channels:
        if not _CHANNEL_RE.match(channel):
            raise RuntimeError(
                f"REQUIRED_CHANNELS da noto'g'ri qiymat: {channel!r}. "
                "Ommaviy kanal username'i kerak, masalan @kanal_nomi"
            )
    return channels


def _parse_webapp_url(raw: str) -> str | None:
    url = raw.strip().rstrip("/")
    if not url:
        return None
    if not re.fullmatch(r"https://[A-Za-z0-9.-]+(:\d+)?(/[^\s]*)?", url):
        raise RuntimeError("WEBAPP_URL https:// bilan boshlanishi kerak (Telegram talabi), masalan https://bot.example.com")
    return url


def _parse_port(raw: str) -> int:
    try:
        port = int(raw)
    except ValueError:
        raise RuntimeError("WEBAPP_PORT butun son bo'lsin")
    if not 1 <= port <= 65535:
        raise RuntimeError("WEBAPP_PORT 1-65535 oralig'ida bo'lsin")
    return port


def load_settings() -> Settings:
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise RuntimeError("BOT_TOKEN .env faylida topilmadi")
    return Settings(
        bot_token=token,
        admin_ids=_parse_admin_ids(os.getenv("ADMIN_IDS", "")),
        db_path=os.getenv("DB_PATH", "cyberstart.db"),
        required_channels=_parse_channels(os.getenv("REQUIRED_CHANNELS", "")),
        webapp_url=_parse_webapp_url(os.getenv("WEBAPP_URL", "")),
        webapp_host=os.getenv("WEBAPP_HOST", "127.0.0.1").strip() or "127.0.0.1",
        webapp_port=_parse_port(os.getenv("WEBAPP_PORT", "8080")),
    )
