"""Maxsus filtrlar."""
from aiogram.filters import BaseFilter
from aiogram.types import TelegramObject, User

from config import Settings


class IsAdmin(BaseFilter):
    """Foydalanuvchi ID .env dagi ADMIN_IDS ro'yxatida bo'lsagina o'tkazadi.

    Router darajasida o'rnatilgani uchun har bir admin xabari/tugmasida tekshiriladi.
    """

    async def __call__(
        self, event: TelegramObject, settings: Settings, event_from_user: User | None = None
    ) -> bool:
        return event_from_user is not None and event_from_user.id in settings.admin_ids
