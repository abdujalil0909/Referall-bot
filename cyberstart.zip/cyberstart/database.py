"""SQLite ulanishi, sxemani yaratish va boshlang'ich kontentni yuklash."""
import json
import logging
from contextlib import asynccontextmanager
from pathlib import Path

import aiosqlite

log = logging.getLogger(__name__)

BASE_DIR = Path(__file__).parent
SCHEMA_PATH = BASE_DIR / "database" / "schema.sql"
CONTENT_PATH = BASE_DIR / "content" / "initial_questions.json"


@asynccontextmanager
async def get_db(db_path: str):
    """Har bir so'rov uchun alohida ulanish; foreign key yoqilgan."""
    async with aiosqlite.connect(db_path, timeout=10) as db:
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys = ON")
        yield db


async def init_db(db_path: str) -> None:
    """Jadvallar va indekslarni yaratadi (mavjud bo'lsa tegmaydi)."""
    schema = SCHEMA_PATH.read_text(encoding="utf-8")
    async with get_db(db_path) as db:
        await db.execute("PRAGMA journal_mode = WAL")
        await db.executescript(schema)
        await db.commit()


def _validate_question(q: dict) -> None:
    options = q["options"]
    if len(options) != 4 or not all(isinstance(o, str) and o.strip() for o in options):
        raise ValueError(f"Savolda aynan 4 ta variant bo'lishi kerak: {q['text']!r}")
    if q["correct"] not in (1, 2, 3, 4):
        raise ValueError(f"To'g'ri javob 1-4 oralig'ida bo'lsin: {q['text']!r}")


async def seed_initial_content(db_path: str, json_path: Path = CONTENT_PATH) -> bool:
    """Mavzular bo'sh bo'lsa, JSON fayldan mavzu, dars va savollarni yuklaydi.

    True qaytarsa — kontent yuklandi, False — baza allaqachon to'ldirilgan.
    """
    data = json.loads(Path(json_path).read_text(encoding="utf-8"))
    async with get_db(db_path) as db:
        cur = await db.execute("SELECT COUNT(*) FROM topics")
        if (await cur.fetchone())[0] > 0:
            return False
        for position, topic in enumerate(data["topics"], start=1):
            cur = await db.execute(
                "INSERT INTO topics (title, position) VALUES (?, ?)", (topic["title"], position)
            )
            topic_id = cur.lastrowid
            lesson = topic["lesson"]
            review = "\n".join(f"{i}. {q}" for i, q in enumerate(lesson["review"], start=1))
            await db.execute(
                "INSERT INTO lessons (topic_id, summary, practical_example, review_questions)"
                " VALUES (?, ?, ?, ?)",
                (topic_id, lesson["summary"], lesson["example"], review),
            )
            for q in topic["questions"]:
                _validate_question(q)
                o = q["options"]
                await db.execute(
                    "INSERT INTO questions (topic_id, text, option_1, option_2, option_3, option_4,"
                    " correct_option, explanation) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (topic_id, q["text"], o[0], o[1], o[2], o[3], q["correct"], q["explanation"]),
                )
        await db.commit()
    log.info("Boshlang'ich kontent yuklandi")
    return True
