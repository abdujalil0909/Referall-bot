"""Majburiy obunani tekshirish (qisqa muddatli kesh bilan)."""
import logging
import time

from aiogram import Bot
from aiogram.enums import ChatMemberStatus
from aiogram.exceptions import TelegramAPIError

log = logging.getLogger(__name__)

_MEMBER_STATUSES = {
    ChatMemberStatus.CREATOR, ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.MEMBER,
}
_MAX_CACHE = 10_000


def is_member(member) -> bool:
    """Kanal a'zosi (yoki cheklangan, lekin kanalda turgan) bo'lsa True."""
    if member.status in _MEMBER_STATUSES:
        return True
    return member.status == ChatMemberStatus.RESTRICTED and bool(getattr(member, "is_member", False))


class SubscriptionChecker:
    def __init__(self, channels: tuple[str, ...], ttl_seconds: int = 60):
        self.channels = tuple(channels)
        self.ttl = ttl_seconds
        self._ok_until: dict[int, float] = {}

    @property
    def enabled(self) -> bool:
        return bool(self.channels)

    async def missing_channels(self, bot: Bot, user_id: int, use_cache: bool = True) -> list[str]:
        """Foydalanuvchi a'zo bo'lmagan kanallar ro'yxati (hammasiga a'zo bo'lsa — bo'sh).

        Kanalni tekshirib bo'lmasa (bot admin emas, kanal topilmadi, tarmoq xatosi) —
        foydalanuvchi bloklanmaydi, xato logga yoziladi.
        """
        if not self.channels:
            return []
        now = time.monotonic()
        if use_cache and self._ok_until.get(user_id, 0) > now:
            return []
        missing = []
        for channel in self.channels:
            try:
                member = await bot.get_chat_member(channel, user_id)
            except TelegramAPIError as exc:
                log.warning("Kanal %s ni tekshirib bo'lmadi: %s", channel, exc)
                continue
            if not is_member(member):
                missing.append(channel)
        if missing:
            self._ok_until.pop(user_id, None)
        else:
            if len(self._ok_until) >= _MAX_CACHE:
                self._ok_until.clear()
            self._ok_until[user_id] = now + self.ttl
        return missing
