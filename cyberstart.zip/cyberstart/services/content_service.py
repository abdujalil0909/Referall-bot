"""Mavzular va o'quv materiallarini o'qish (hamma foydalanuvchi uchun)."""
import aiosqlite


async def list_topics(db: aiosqlite.Connection) -> list[dict]:
    cur = await db.execute("SELECT id, title, position FROM topics ORDER BY position, id")
    return [dict(r) for r in await cur.fetchall()]


async def get_topic(db: aiosqlite.Connection, topic_id: int) -> dict | None:
    cur = await db.execute("SELECT id, title FROM topics WHERE id = ?", (topic_id,))
    row = await cur.fetchone()
    return dict(row) if row else None


async def get_lessons(db: aiosqlite.Connection, topic_id: int) -> list[dict]:
    cur = await db.execute(
        "SELECT id, summary, practical_example, review_questions"
        " FROM lessons WHERE topic_id = ? ORDER BY id",
        (topic_id,),
    )
    return [dict(r) for r in await cur.fetchall()]
