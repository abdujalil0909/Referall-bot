"""Foydalanuvchi kiritgan ma'lumotni tekshirish va tozalash."""
import re

_CONTROL_CHARS = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")

# Admin tahrirlaganda maydon bo'yicha maksimal uzunlik
FIELD_LIMITS = {
    "text": 300,
    "explanation": 300,
    "option_1": 150,
    "option_2": 150,
    "option_3": 150,
    "option_4": 150,
}


def clean_text(value, max_len: int, min_len: int = 1) -> str | None:
    """Matnni tozalaydi. Noto'g'ri bo'lsa (bo'sh, uzun, matn emas) None qaytaradi."""
    if not isinstance(value, str):
        return None
    value = _CONTROL_CHARS.sub("", value).strip()
    if not (min_len <= len(value) <= max_len):
        return None
    return value


def parse_field_value(field: str, raw):
    """Savol maydoni uchun qiymatni tekshiradi. Yaroqsiz bo'lsa None."""
    if field == "correct_option":
        try:
            number = int(str(raw).strip())
        except ValueError:
            return None
        return number if 1 <= number <= 4 else None
    limit = FIELD_LIMITS.get(field)
    return clean_text(raw, limit) if limit else None
