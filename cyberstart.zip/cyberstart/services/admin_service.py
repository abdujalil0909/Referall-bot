"""Admin amallari. Har bir funksiya boshida admin huquqi qayta tekshiriladi."""
import aiosqlite

EDITABLE_FIELDS = {
    "text", "option_1", "option_2", "option_3", "option_4", "correct_option", "explanation",
}
PAGE_SIZE = 5


def require_admin(admin_ids: frozenset[int], user_id: int) -> None:
    """Admin bo'lmasa PermissionError ko'taradi."""
    if user_id not in admin_ids:
        raise PermissionError("Admin huquqi yo'q")


async def add_lesson(
    db: aiosqlite.Connection, admin_ids, user_id: int,
    topic_id: int, summary: str, example: str, review: str,
) -> int:
    require_admin(admin_ids, user_id)
    cur = await db.execute(
        "INSERT INTO lessons (topic_id, summary, practical_example, review_questions)"
        " VALUES (?, ?, ?, ?)",
        (topic_id, summary, example, review),
    )
    await db.commit()
    return cur.lastrowid


async def add_question(
    db: aiosqlite.Connection, admin_ids, user_id: int,
    topic_id: int, text: str, options: list[str], correct: int, explanation: str,
) -> int:
    require_admin(admin_ids, user_id)
    if len(options) != 4 or correct not in (1, 2, 3, 4):
        raise ValueError("4 ta variant va 1-4 oralig'ida to'g'ri javob kerak")
    cur = await db.execute(
        "INSERT INTO questions (topic_id, text, option_1, option_2, option_3, option_4,"
        " correct_option, explanation) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (topic_id, text, *options, correct, explanation),
    )
    await db.commit()
    return cur.lastrowid


async def list_questions(
    db: aiosqlite.Connection, admin_ids, user_id: int, topic_id: int, page: int
) -> tuple[list[dict], int]:
    """Mavzu savollarining bir sahifasi va jami savollar soni."""
    require_admin(admin_ids, user_id)
    cur = await db.execute("SELECT COUNT(*) FROM questions WHERE topic_id = ?", (topic_id,))
    total = (await cur.fetchone())[0]
    cur = await db.execute(
        "SELECT id, text FROM questions WHERE topic_id = ? ORDER BY id LIMIT ? OFFSET ?",
        (topic_id, PAGE_SIZE, max(page, 0) * PAGE_SIZE),
    )
    return [dict(r) for r in await cur.fetchall()], total


async def get_question(db: aiosqlite.Connection, admin_ids, user_id: int, question_id: int):
    require_admin(admin_ids, user_id)
    cur = await db.execute("SELECT * FROM questions WHERE id = ?", (question_id,))
    row = await cur.fetchone()
    return dict(row) if row else None


async def update_question_field(
    db: aiosqlite.Connection, admin_ids, user_id: int, question_id: int, field: str, value
) -> bool:
    """Savolning bitta maydonini yangilaydi. Maydon nomi faqat oq ro'yxatdan olinadi."""
    require_admin(admin_ids, user_id)
    if field not in EDITABLE_FIELDS:
        raise ValueError("Bu maydonni tahrirlab bo'lmaydi")
    cur = await db.execute(
        f"UPDATE questions SET {field} = ? WHERE id = ?",  # field oq ro'yxatdan — xavfsiz
        (value, question_id),
    )
    await db.commit()
    return cur.rowcount == 1


async def delete_question(
    db: aiosqlite.Connection, admin_ids, user_id: int, question_id: int
) -> dict | None:
    """Savolni o'chiradi. Mavzu ID va qolgan savollar sonini qaytaradi."""
    require_admin(admin_ids, user_id)
    cur = await db.execute("SELECT topic_id FROM questions WHERE id = ?", (question_id,))
    row = await cur.fetchone()
    if row is None:
        return None
    topic_id = row[0]
    await db.execute("DELETE FROM questions WHERE id = ?", (question_id,))
    await db.commit()
    cur = await db.execute("SELECT COUNT(*) FROM questions WHERE topic_id = ?", (topic_id,))
    return {"topic_id": topic_id, "remaining": (await cur.fetchone())[0]}


async def get_bot_stats(db: aiosqlite.Connection, admin_ids, user_id: int) -> dict:
    require_admin(admin_ids, user_id)

    async def scalar(sql: str):
        cur = await db.execute(sql)
        return (await cur.fetchone())[0]

    return {
        "users": await scalar("SELECT COUNT(*) FROM users"),
        "new_users_24h": await scalar(
            "SELECT COUNT(*) FROM users WHERE registered_at >= datetime('now', '-1 day')"),
        "topics": await scalar("SELECT COUNT(*) FROM topics"),
        "lessons": await scalar("SELECT COUNT(*) FROM lessons"),
        "questions": await scalar("SELECT COUNT(*) FROM questions"),
        "finished_tests": await scalar("SELECT COUNT(*) FROM test_attempts WHERE status = 'finished'"),
        "tests_24h": await scalar(
            "SELECT COUNT(*) FROM test_attempts WHERE status = 'finished'"
            " AND finished_at >= datetime('now', '-1 day')"),
        "average_percent": round(await scalar(
            "SELECT COALESCE(AVG(100.0 * score / total), 0) FROM test_attempts"
            " WHERE status = 'finished'")),
    }
