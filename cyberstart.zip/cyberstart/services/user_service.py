"""Foydalanuvchilar, profil statistikasi va reyting. Barcha so'rovlar parametrli."""
import aiosqlite

MASTERED_PERCENT = 80  # mavzu o'zlashtirilgan hisoblanadigan eng kam foiz
LEADERBOARD_SIZE = 10


async def register_user(
    db: aiosqlite.Connection, telegram_id: int, full_name: str, username: str | None
) -> None:
    """Yangi foydalanuvchini qo'shadi, mavjud bo'lsa ismini yangilaydi."""
    await db.execute(
        """
        INSERT INTO users (telegram_id, full_name, username)
        VALUES (?, ?, ?)
        ON CONFLICT(telegram_id) DO UPDATE SET
            full_name = excluded.full_name,
            username = excluded.username
        """,
        (telegram_id, full_name[:200], username),
    )
    await db.commit()


async def get_user(db: aiosqlite.Connection, telegram_id: int) -> dict | None:
    """Faqat so'ralgan foydalanuvchining o'z ma'lumotini qaytaradi."""
    cur = await db.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_id,))
    row = await cur.fetchone()
    return dict(row) if row else None


async def count_users(db: aiosqlite.Connection) -> int:
    cur = await db.execute("SELECT COUNT(*) FROM users")
    return (await cur.fetchone())[0]


async def get_profile_stats(db: aiosqlite.Connection, user_id: int) -> dict | None:
    """Foydalanuvchining o'z natijalari (real bazadan)."""
    user = await get_user(db, user_id)
    if user is None:
        return None
    cur = await db.execute(
        "SELECT COALESCE(AVG(100.0 * score / total), 0) FROM test_attempts"
        " WHERE user_id = ? AND status = 'finished'",
        (user_id,),
    )
    average = round((await cur.fetchone())[0])
    cur = await db.execute(
        """
        SELECT t.title AS title, MAX(ROUND(100.0 * a.score / a.total)) AS best
        FROM test_attempts a JOIN topics t ON t.id = a.topic_id
        WHERE a.user_id = ? AND a.status = 'finished'
        GROUP BY t.id HAVING best >= ?
        ORDER BY t.position
        """,
        (user_id, MASTERED_PERCENT),
    )
    mastered = [dict(r) for r in await cur.fetchall()]
    cur = await db.execute(
        """
        SELECT t.title AS title, a.score AS score, a.total AS total, a.finished_at AS finished_at
        FROM test_attempts a JOIN topics t ON t.id = a.topic_id
        WHERE a.user_id = ? AND a.status = 'finished'
        ORDER BY a.finished_at DESC, a.id DESC LIMIT 5
        """,
        (user_id,),
    )
    recent = [dict(r) for r in await cur.fetchall()]
    return {"user": user, "average": average, "mastered": mastered, "recent": recent}


async def get_leaderboard(db: aiosqlite.Connection, limit: int = LEADERBOARD_SIZE) -> list[dict]:
    """Eng yaxshi foydalanuvchilar.

    Tenglik qoidasi: ball teng bo'lsa — eng yaxshi natija (foiz) yuqorisi,
    u ham teng bo'lsa — erta ro'yxatdan o'tgani, oxirgi chora — kichik Telegram ID.
    """
    cur = await db.execute(
        "SELECT full_name, total_score, best_percent FROM users WHERE total_score > 0"
        " ORDER BY total_score DESC, best_percent DESC, registered_at ASC, telegram_id ASC"
        " LIMIT ?",
        (limit,),
    )
    return [dict(r) for r in await cur.fetchall()]


async def get_user_rank(db: aiosqlite.Connection, user_id: int) -> int | None:
    """Foydalanuvchining reytingdagi o'rni (ball 0 bo'lsa — None). Tenglik qoidasi yuqoridagidek."""
    user = await get_user(db, user_id)
    if user is None or user["total_score"] <= 0:
        return None
    cur = await db.execute(
        """
        SELECT COUNT(*) + 1 FROM users
        WHERE total_score > :s
           OR (total_score = :s AND best_percent > :b)
           OR (total_score = :s AND best_percent = :b AND registered_at < :r)
           OR (total_score = :s AND best_percent = :b AND registered_at = :r AND telegram_id < :id)
        """,
        {"s": user["total_score"], "b": user["best_percent"],
         "r": user["registered_at"], "id": user_id},
    )
    return (await cur.fetchone())[0]
