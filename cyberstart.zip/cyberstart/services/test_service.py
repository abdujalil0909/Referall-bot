"""Test mantig'i: boshlash, javob qabul qilish, yakunlash.

Test holati bazada saqlanadi (test_attempts.question_ids + test_answers),
shuning uchun bot qayta ishga tushsa ham test davom ettirilishi mumkin.
"""
import json

import aiosqlite

QUESTIONS_PER_TEST = 10


def calc_percent(score: int, total: int) -> int:
    return round(100 * score / total) if total else 0


async def _fetch_one(db: aiosqlite.Connection, sql: str, params: tuple) -> dict | None:
    cur = await db.execute(sql, params)
    row = await cur.fetchone()
    return dict(row) if row else None


async def start_attempt(db: aiosqlite.Connection, user_id: int, topic_id: int) -> dict | None:
    """Yangi test boshlaydi. Eski tugallanmagan testlar bekor qilinadi.

    Mavzuda savol bo'lmasa None qaytaradi.
    """
    await db.execute(
        "UPDATE test_attempts SET status = 'abandoned', finished_at = datetime('now')"
        " WHERE user_id = ? AND status = 'in_progress'",
        (user_id,),
    )
    cur = await db.execute(
        "SELECT id FROM questions WHERE topic_id = ? ORDER BY RANDOM() LIMIT ?",
        (topic_id, QUESTIONS_PER_TEST),
    )
    question_ids = [row[0] for row in await cur.fetchall()]
    if not question_ids:
        await db.commit()
        return None
    cur = await db.execute(
        "INSERT INTO test_attempts (user_id, topic_id, total, question_ids) VALUES (?, ?, ?, ?)",
        (user_id, topic_id, len(question_ids), json.dumps(question_ids)),
    )
    await db.commit()
    return {"id": cur.lastrowid, "total": len(question_ids), "topic_id": topic_id}


async def get_attempt(db: aiosqlite.Connection, attempt_id: int, user_id: int) -> dict | None:
    """Faqat shu foydalanuvchiga tegishli urinishni qaytaradi (boshqasiniki — None)."""
    return await _fetch_one(
        db, "SELECT * FROM test_attempts WHERE id = ? AND user_id = ?", (attempt_id, user_id)
    )


async def get_current_question(db: aiosqlite.Connection, attempt: dict) -> dict | None:
    """Javob berilmagan navbatdagi savolni qaytaradi; qolmagan bo'lsa None."""
    question_ids = json.loads(attempt["question_ids"])
    cur = await db.execute(
        "SELECT question_id FROM test_answers WHERE attempt_id = ?", (attempt["id"],)
    )
    rows = await cur.fetchall()
    answered = {row[0] for row in rows if row[0] is not None}
    for question_id in question_ids:
        if question_id in answered:
            continue
        question = await _fetch_one(db, "SELECT * FROM questions WHERE id = ?", (question_id,))
        if question:  # admin o'chirib yuborgan savol o'tkazib yuboriladi
            question["number"] = len(rows) + 1
            question["total"] = attempt["total"]
            return question
    return None


async def submit_answer(
    db: aiosqlite.Connection, attempt: dict, question_id: int, option: int
) -> dict | None:
    """Javobni saqlaydi. Eskirgan, takroriy yoki noto'g'ri so'rov bo'lsa None."""
    if attempt["status"] != "in_progress" or option not in (1, 2, 3, 4):
        return None
    question = await get_current_question(db, attempt)
    if question is None or question["id"] != question_id:
        return None
    is_correct = option == question["correct_option"]
    try:
        await db.execute(
            "INSERT INTO test_answers (attempt_id, question_id, chosen_option, is_correct)"
            " VALUES (?, ?, ?, ?)",
            (attempt["id"], question_id, option, int(is_correct)),
        )
    except aiosqlite.IntegrityError:  # bir vaqtda ikki marta bosilgan
        return None
    if is_correct:
        await db.execute("UPDATE test_attempts SET score = score + 1 WHERE id = ?", (attempt["id"],))
    await db.commit()
    return {"is_correct": is_correct, "question": question, "chosen": option}


async def finish_attempt(db: aiosqlite.Connection, attempt_id: int, user_id: int) -> dict | None:
    """Testni yakunlaydi va foydalanuvchi statistikasini yangilaydi.

    Funksiya takror chaqirilsa ham statistika faqat bir marta yangilanadi.
    """
    attempt = await get_attempt(db, attempt_id, user_id)
    if attempt is None or attempt["status"] == "abandoned":
        return None
    if attempt["status"] == "in_progress":
        cur = await db.execute(
            "SELECT COUNT(*) FROM test_answers WHERE attempt_id = ?", (attempt_id,)
        )
        answered = (await cur.fetchone())[0]
        cur = await db.execute(
            "UPDATE test_attempts SET status = 'finished', finished_at = datetime('now'),"
            " total = ? WHERE id = ? AND status = 'in_progress'",
            (max(answered, 1), attempt_id),
        )
        newly_finished = cur.rowcount == 1
        attempt = await get_attempt(db, attempt_id, user_id)
        if newly_finished:
            percent = calc_percent(attempt["score"], attempt["total"])
            await db.execute(
                "UPDATE users SET tests_taken = tests_taken + 1,"
                " total_score = total_score + ?, best_percent = MAX(best_percent, ?)"
                " WHERE telegram_id = ?",
                (attempt["score"], percent, user_id),
            )
        await db.commit()
    topic = await _fetch_one(db, "SELECT title FROM topics WHERE id = ?", (attempt["topic_id"],))
    return {
        "score": attempt["score"],
        "total": attempt["total"],
        "percent": calc_percent(attempt["score"], attempt["total"]),
        "topic_id": attempt["topic_id"],
        "topic_title": topic["title"] if topic else "—",
    }
