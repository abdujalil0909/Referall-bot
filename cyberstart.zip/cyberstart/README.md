# CyberStart — Telegram bot

Axborot xavfsizligini o'rganayotgan talabalar va yangi boshlovchilar uchun: o'quv materiallari, 10 savollik testlar, natijalar, reyting va admin paneli. Interfeys — o'zbek tilida.

## 1. Python o'rnatish
Python 3.11 yoki yangisi kerak (https://www.python.org/downloads/). Tekshirish:

    python --version

Windows'da o'rnatishda "Add Python to PATH" katagini belgilang. Linux/macOS'da buyruq `python3` bo'lishi mumkin.

## 2. Virtual muhit yaratish
    python -m venv .venv

Yoqish:
- Windows: `.venv\Scripts\activate`
- Linux/macOS: `source .venv/bin/activate`

## 3. Kutubxonalarni o'rnatish
    pip install -r requirements.txt

## 4. .env sozlash
    cp .env.example .env        (Windows: copy .env.example .env)

`.env` faylini oching:
- `BOT_TOKEN` — @BotFather dan olingan token.
- `ADMIN_IDS` — admin Telegram ID'lari, vergul bilan (o'z ID'ngizni @userinfobot dan bilib oling).
- `DB_PATH` — baza fayli nomi (ixtiyoriy, standart: cyberstart.db).
- `REQUIRED_CHANNELS` — majburiy obuna kanallari, masalan `@kanal1,@kanal2` (ixtiyoriy; bo'sh bo'lsa o'chiq).

`.env` Git'ga yuklanmaydi (.gitignore'da). Tokenni hech qachon kodga yozmang.

## 5. Ma'lumotlar bazasini yaratish
Alohida qadam shart emas: bot birinchi ishga tushganda `cyberstart.db` ni, jadvallarni va boshlang'ich kontentni (8 mavzu, 8 dars, 80 savol) o'zi yaratadi. Qo'lda yaratish:

    python -c "import asyncio, database; asyncio.run(database.init_db('cyberstart.db')); asyncio.run(database.seed_initial_content('cyberstart.db'))"

## 6. Botni ishga tushirish
    python bot.py

To'xtatish: Ctrl+C. Xatolar `cyberstart.log` fayliga yoziladi (token yashiriladi).

## 7. Sinovlar
    python -m unittest discover -s tests -t . -v

Sinovlar haqiqiy bazada (vaqtinchalik fayl) va soxta Telegram sessiyasida ishlaydi, internet kerak emas. Haqiqiy Telegram bilan ishlashni o'zingiz botga yozib tekshiring.

## Papkalar
    bot.py            kirish nuqtasi, dispatcher, log, xato handleri
    config.py         .env sozlamalari
    database.py       ulanish, sxema, boshlang'ich kontent
    filters.py        IsAdmin filtri
    middlewares.py    baza ulanishi va majburiy obuna
    webapp/           Telegram Web App: server.py (aiohttp API), static/ (sahifa)
    handlers/         faqat Telegram bilan ishlash (start, learning, tests, profile, leaderboard, admin)
    services/         biznes mantiq (test, foydalanuvchi, kontent, admin, tekshiruvlar)
    keyboards/        reply va inline tugmalar
    database/schema.sql   jadvallar, indekslar, cheklovlar
    content/initial_questions.json   mavzular, darslar, savollar
    tests/            sinovlar

## Web App (Telegram Mini App)
Botning barcha bo'limlari (O'rganish, Test, Natijalar, Reyting, Haqida) Web App'da ham bor. U bot bilan bir jarayonda ishlaydi va bir xil bazadan foydalanadi.

Telegram Web App uchun **ommaviy HTTPS manzil** shart. Sozlash:
1. Botni ishga tushiring (`python bot.py`). Web App serveri `WEBAPP_HOST:WEBAPP_PORT` da (standart 127.0.0.1:8080) ochiladi.
2. Shu portni HTTPS orqali internetga chiqaring:
   - sinov uchun: `cloudflared tunnel --url http://localhost:8080` (yoki ngrok), chiqqan `https://...` manzilni oling;
   - doimiy ishlash uchun: serverda nginx/Caddy orqali domen + HTTPS, so'rovlarni `127.0.0.1:8080` ga yo'naltiring.
3. `.env` ga yozing: `WEBAPP_URL=https://sizning-manzil` (oxirida `/` shart emas), botni qayta ishga tushiring.
4. Botda ochish yo'llari: chat maydoni yonidagi menyu tugmasi "🌐 Web App", menyudagi "🌐 Web App" tugmasi yoki `/app` buyrug'i.

`WEBAPP_URL` bo'sh bo'lsa, Web App o'chiq. Tunnel manzili har ishga tushganda o'zgarsa, `.env` ni yangilab, botni qayta ishga tushiring.

Xavfsizlik: har bir so'rov Telegram `initData` imzosi (bot tokeni bilan HMAC) orqali tekshiriladi, foydalanuvchi ID faqat imzolangan ma'lumotdan olinadi, 24 soatdan eski ma'lumot rad etiladi. To'g'ri javob savolga javob berilgandan keyingina yuboriladi. Majburiy obuna Web App'da ham ishlaydi (adminlar bundan mustasno).

## Majburiy obuna
`REQUIRED_CHANNELS` to'ldirilsa, obuna bo'lmagan foydalanuvchi hech bir funksiyadan foydalana olmaydi: unga kanal tugmalari va "✅ Tekshirish" tugmasi chiqadi.
- Faqat ommaviy kanallar (`@username`) qo'llab-quvvatlanadi.
- **Bot har bir kanalda administrator bo'lishi shart**, aks holda a'zolikni tekshira olmaydi.
- Kanal tekshirib bo'lmasa (bot admin emas, username xato), foydalanuvchi bloklanmaydi, xato `cyberstart.log` ga yoziladi.
- Adminlar (`ADMIN_IDS`) tekshirilmaydi. A'zolik natijasi 60 soniya keshlanadi; "Tekshirish" tugmasi keshni chetlab o'tadi.

## Qoidalar
- **Reyting:** top 10, to'plangan ball bo'yicha. Ball teng bo'lsa: eng yaxshi natija (foiz) yuqorisi, u ham teng bo'lsa — erta ro'yxatdan o'tgani, oxirgi chora — kichik Telegram ID. Reytingda faqat ism ko'rsatiladi (ID va username yo'q).
- **Ball:** har bir to'g'ri javob 1 ball; qayta ishlangan test ham jamlanadi.
- **Test holati** bazada saqlanadi; yangi test boshlansa, eski tugallanmagani bekor qilinadi.
- **Admin:** `/admin`. Tekshiruv router filtrida va har bir servis funksiyasida takrorlanadi.
- **Kontent qo'shish:** admin panelidan (dars, savol) yoki `content/initial_questions.json` ni tahrirlab, bo'sh bazada qayta ishga tushirib.

## Muammolarni bartaraf etish
- Web App "Telegram ichida oching" deydi — Web App'ni brauzerdan emas, botdagi tugma (menyu tugmasi, "🌐 Web App" yoki /app) orqali oching.
- Web App ochilmaydi / oq ekran — `WEBAPP_URL` ommaviy HTTPS manzil ekanini, tunnel ishlayotganini va portlar mosligini tekshiring (`https://manzil/healthz` "ok" qaytarishi kerak).
- `WEBAPP_URL https:// bilan boshlanishi kerak` — Telegram faqat HTTPS qabul qiladi; `http://` va `localhost` ishlamaydi.
- `BOT_TOKEN .env faylida topilmadi` — `.env` fayli loyiha papkasida ekanini va `BOT_TOKEN=` to'ldirilganini tekshiring.
- `ADMIN_IDS faqat ... raqamlar bo'lsin` — faqat raqam va vergul yozing: `ADMIN_IDS=123,456`.
- `ModuleNotFoundError` — virtual muhit yoqilganini va `pip install -r requirements.txt` bajarilganini tekshiring.
- `Unauthorized` / 401 — token noto'g'ri yoki bekor qilingan; @BotFather'dan yangisini oling.
- Obuna so'rovi chiqmayapti yoki hamma o'tib ketyapti — botni kanalga administrator qiling va `cyberstart.log` dagi "tekshirib bo'lmadi" xabarini qidiring.
- Bot javob bermaydi — botga /start yuboring; bir tokenda ikkita nusxa ishlamasin (conflict xatosi).
- `database is locked` — bot nusxalaridan bittasini qoldiring.
- Kontent yangilanmadi — kontent faqat bo'sh bazaga yuklanadi; tozalash uchun `cyberstart.db` ni o'chiring (foydalanuvchi ma'lumotlari ham o'chadi!).
