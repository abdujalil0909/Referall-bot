"""CyberStart boti: kirish nuqtasi."""
import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ChatMemberStatus, ChatType, ParseMode
from aiogram.exceptions import TelegramAPIError
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import ErrorEvent, MenuButtonWebApp, WebAppInfo

from config import Settings, load_settings
from database import init_db, seed_initial_content
from handlers import admin, leaderboard, learning, profile, start, tests
from keyboards.main_menu import configure_webapp
from middlewares import DbMiddleware, SubscriptionMiddleware
from services.subscription_service import SubscriptionChecker
from webapp.server import start_webapp

log = logging.getLogger("cyberstart")


class RedactingFormatter(logging.Formatter):
    """Log chiqishidan bot tokenini yashiradi."""

    def __init__(self, secret: str):
        super().__init__("%(asctime)s %(levelname)s %(name)s: %(message)s")
        self._secret = secret

    def format(self, record: logging.LogRecord) -> str:
        text = super().format(record)
        return text.replace(self._secret, "***") if self._secret else text


def setup_logging(token: str) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(RedactingFormatter(token))
    file_handler = logging.FileHandler("cyberstart.log", encoding="utf-8")
    file_handler.setFormatter(RedactingFormatter(token))
    logging.basicConfig(level=logging.INFO, handlers=[handler, file_handler], force=True)


async def on_error(event: ErrorEvent) -> bool:
    """Kutilmagan xatoni logga yozadi (token yashirilgan) va foydalanuvchiga xabar beradi."""
    log.error("Handlerda xato: %s", event.exception, exc_info=event.exception)
    try:
        update = event.update
        if update.callback_query:
            await update.callback_query.answer("Xatolik yuz berdi. Keyinroq urinib ko'ring.", show_alert=True)
        elif update.message:
            await update.message.answer("Xatolik yuz berdi. Keyinroq urinib ko'ring.")
    except Exception:  # xabar yuborib bo'lmasa, e'tiborsiz qoldiramiz
        log.warning("Foydalanuvchiga xato haqida xabar yuborib bo'lmadi")
    return True


def build_dispatcher(settings: Settings) -> Dispatcher:
    """Dispatcher, middleware va routerlarni yig'adi (sinovlarda ham ishlatiladi)."""
    configure_webapp(settings.webapp_url)  # menyuga "🌐 Web App" tugmasi
    checker = SubscriptionChecker(settings.required_channels)
    dp = Dispatcher(storage=MemoryStorage(), settings=settings, subscription=checker)
    dp.message.filter(F.chat.type == ChatType.PRIVATE)  # faqat shaxsiy chat
    # Tartib: avval baza ulanishi, keyin obuna tekshiruvi
    for observer in (dp.message, dp.callback_query):
        observer.outer_middleware(DbMiddleware(settings))
        observer.outer_middleware(SubscriptionMiddleware(settings, checker))
    # Tartib muhim: menyu tugmalari FSM holatidan oldin, fallback eng oxirida
    dp.include_routers(
        start.router, learning.router, tests.router, profile.router,
        leaderboard.router, admin.router, start.fallback_router,
    )
    dp.errors.register(on_error)
    return dp


async def check_channels(bot: Bot, settings: Settings) -> None:
    """Ishga tushganda: bot majburiy kanallarda admin ekanini tekshirib, xato bo'lsa ogohlantiradi.

    Aks holda obuna tekshiruvi jimgina ishlamay qolardi (foydalanuvchilar bloklanmaydi).
    """
    if not settings.required_channels:
        return
    me = await bot.me()
    for channel in settings.required_channels:
        try:
            member = await bot.get_chat_member(channel, me.id)
        except TelegramAPIError as exc:
            log.warning("Kanal %s tekshirilmadi (nomi noto'g'ri yoki bot kanalda yo'q): %s", channel, exc)
            continue
        if member.status not in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR):
            log.warning("Bot %s kanalida admin emas: obuna tekshiruvi ishlamaydi. Botni admin qiling.", channel)


async def main() -> None:
    settings = load_settings()
    setup_logging(settings.bot_token)
    await init_db(settings.db_path)
    await seed_initial_content(settings.db_path)
    bot = Bot(settings.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = build_dispatcher(settings)
    if settings.required_channels:
        log.info("Majburiy obuna yoqilgan: %s", ", ".join(settings.required_channels))
        await check_channels(bot, settings)
    runner = None
    if settings.webapp_url:
        runner = await start_webapp(settings, bot, dp.workflow_data["subscription"])
        try:  # chatdagi menyu tugmasi ham Web App'ni ochadi
            await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(
                text="🌐 Web App", web_app=WebAppInfo(url=settings.webapp_url)))
        except TelegramAPIError as exc:
            log.warning("Menyu tugmasini o'rnatib bo'lmadi: %s", exc)
    log.info("Bot ishga tushdi")
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)
    finally:
        if runner:
            await runner.cleanup()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
