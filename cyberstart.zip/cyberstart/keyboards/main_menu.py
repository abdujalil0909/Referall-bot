"""Asosiy menyu (reply) klaviaturasi."""
from aiogram.types import KeyboardButton, ReplyKeyboardMarkup

BTN_LEARN = "🛡️ O'rganish"
BTN_TEST = "📝 Test ishlash"
BTN_RESULTS = "📊 Mening natijalarim"
BTN_RANK = "🏆 Reyting"
BTN_ABOUT = "ℹ️ Loyiha haqida"
BTN_WEBAPP = "🌐 Web App"

_webapp_url: str | None = None


def configure_webapp(url: str | None) -> None:
    """Web App manzilini o'rnatadi; berilsa, menyuga "🌐 Web App" tugmasi qo'shiladi.

    Tugma oddiy matnli: reply-klaviaturadan ochilgan Web App'da Telegram initData bermaydi,
    shuning uchun bosilganda bot inline web_app tugmasini yuboradi (handlers/start.py)."""
    global _webapp_url
    _webapp_url = url


def main_menu_kb() -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton(text=BTN_LEARN), KeyboardButton(text=BTN_TEST)],
        [KeyboardButton(text=BTN_RESULTS), KeyboardButton(text=BTN_RANK)],
        [KeyboardButton(text=BTN_ABOUT)],
    ]
    if _webapp_url:
        rows.append([KeyboardButton(text=BTN_WEBAPP)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)
