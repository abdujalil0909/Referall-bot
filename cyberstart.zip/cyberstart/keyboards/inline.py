"""Inline klaviaturalar. callback_data 64 baytdan oshmasligi kerak."""
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

NUMBERS = ["1️⃣", "2️⃣", "3️⃣", "4️⃣"]


def _btn(text: str, data: str) -> InlineKeyboardButton:
    return InlineKeyboardButton(text=text, callback_data=data)


def _kb(rows: list[list[InlineKeyboardButton]]) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=rows)


MENU_ROW = [_btn("🏠 Menyu", "menu")]


def topics_kb(topics: list[dict], prefix: str, back_data: str = "menu") -> InlineKeyboardMarkup:
    """Mavzular ro'yxati. Tugma ma'lumoti: '<prefix>:<topic_id>'."""
    rows = [[_btn(f"{i}. {t['title']}", f"{prefix}:{t['id']}")] for i, t in enumerate(topics, 1)]
    rows.append([_btn("🏠 Menyu" if back_data == "menu" else "⬅️ Orqaga", back_data)])
    return _kb(rows)


def lesson_kb(topic_id: int, index: int, total: int) -> InlineKeyboardMarkup:
    nav = []
    if index > 0:
        nav.append(_btn("◀️", f"l:{topic_id}:{index - 1}"))
    nav.append(_btn(f"{index + 1}/{total}", "noop"))
    if index < total - 1:
        nav.append(_btn("▶️", f"l:{topic_id}:{index + 1}"))
    return _kb([
        nav,
        [_btn("📝 Shu mavzu bo'yicha test", f"tt:{topic_id}")],
        [_btn("🗂 Mavzular", "learn"), *MENU_ROW],
    ])


def answer_kb(attempt_id: int, question_id: int) -> InlineKeyboardMarkup:
    return _kb([[_btn(NUMBERS[i], f"a:{attempt_id}:{question_id}:{i + 1}") for i in range(4)]])


def next_kb(attempt_id: int, is_last: bool) -> InlineKeyboardMarkup:
    label = "🏁 Natijani ko'rish" if is_last else "➡️ Keyingi savol"
    return _kb([[_btn(label, f"n:{attempt_id}")]])


def result_kb(topic_id: int) -> InlineKeyboardMarkup:
    return _kb([
        [_btn("🔁 Qayta ishlash", f"tt:{topic_id}")],
        [_btn("📝 Boshqa mavzu", "tests"), *MENU_ROW],
    ])


# ---------- admin ----------
def admin_menu_kb() -> InlineKeyboardMarkup:
    return _kb([
        [_btn("👥 Foydalanuvchilar soni", "adm:users"), _btn("📈 Statistika", "adm:stats")],
        [_btn("➕ O'quv materiali", "adm:al"), _btn("➕ Test savoli", "adm:aq")],
        [_btn("✏️ Savollarni boshqarish", "adm:mq")],
        MENU_ROW,
    ])


def admin_back_kb() -> InlineKeyboardMarkup:
    return _kb([[_btn("⬅️ Admin paneli", "adm:menu")]])


def correct_option_kb() -> InlineKeyboardMarkup:
    return _kb([[_btn(NUMBERS[i], f"adm:qc:{i + 1}") for i in range(4)]])


def question_list_kb(topic_id: int, questions: list[dict], page: int, total: int, page_size: int):
    rows = [[_btn(f"#{q['id']} {q['text'][:40]}", f"adm:q:{q['id']}")] for q in questions]
    nav = []
    if page > 0:
        nav.append(_btn("◀️", f"adm:mql:{topic_id}:{page - 1}"))
    if (page + 1) * page_size < total:
        nav.append(_btn("▶️", f"adm:mql:{topic_id}:{page + 1}"))
    if nav:
        rows.append(nav)
    rows.append([_btn("⬅️ Mavzular", "adm:mq"), _btn("🛠 Panel", "adm:menu")])
    return _kb(rows)


def question_detail_kb(question_id: int, topic_id: int) -> InlineKeyboardMarkup:
    return _kb([
        [_btn("✏️ Matn", f"adm:qe:{question_id}:text"),
         _btn("💡 Izoh", f"adm:qe:{question_id}:explanation")],
        [_btn(f"✏️ {i}-variant", f"adm:qe:{question_id}:option_{i}") for i in (1, 2)],
        [_btn(f"✏️ {i}-variant", f"adm:qe:{question_id}:option_{i}") for i in (3, 4)],
        [_btn("✅ To'g'ri javob", f"adm:qe:{question_id}:correct_option")],
        [_btn("🗑 O'chirish", f"adm:qd:{question_id}")],
        [_btn("⬅️ Ro'yxat", f"adm:mql:{topic_id}:0")],
    ])


def confirm_delete_kb(question_id: int) -> InlineKeyboardMarkup:
    return _kb([[_btn("✅ Ha, o'chirish", f"adm:qdy:{question_id}"),
                 _btn("❌ Yo'q", f"adm:q:{question_id}")]])


def webapp_kb(url: str) -> InlineKeyboardMarkup:
    """Web App'ni ochuvchi inline tugma (initData faqat shu usulda va menyu tugmasida beriladi)."""
    return _kb([[InlineKeyboardButton(text="🌐 Web App’ni ochish", web_app=WebAppInfo(url=url))]])


# ---------- majburiy obuna ----------
def subscribe_kb(channels) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton(text=f"📢 {ch}", url=f"https://t.me/{ch.lstrip('@')}")]
        for ch in channels
    ]
    rows.append([_btn("✅ Tekshirish", "sub:check")])
    return _kb(rows)
