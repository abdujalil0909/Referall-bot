"""Telegram Mini App (Web App) serveri: statik sahifa + JSON API (aiohttp).

Xavfsizlik:
- Har bir /api so'rov Telegram initData imzosi bilan tekshiriladi (bot tokeni orqali HMAC),
  foydalanuvchi ID faqat imzolangan ma'lumotdan olinadi, so'rov tanasidan emas.
- initData 24 soatdan eski bo'lsa, rad etiladi.
- To'g'ri javob va izoh savolga javob berilgandan keyingina yuboriladi.
- Majburiy obuna va admin qoidalari botdagi kabi ishlaydi.
"""
import logging
import time
from pathlib import Path

from aiogram import Bot
from aiogram.utils.web_app import safe_parse_webapp_init_data
from aiohttp import web

from config import Settings
from database import get_db
from services import content_service, test_service, user_service
from services.subscription_service import SubscriptionChecker

log = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"
MAX_AUTH_AGE = 24 * 3600  # initData amal qilish muddati (soniya)
CSP = (
    "default-src 'self'; script-src 'self' https://telegram.org; style-src 'self'; "
    "connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'"
)


class ApiError(Exception):
    def __init__(self, status: int, code: str, **extra):
        self.status, self.code, self.extra = status, code, extra


def _reply(data: dict, status: int = 200) -> web.Response:
    return web.json_response(data, status=status, headers={"Cache-Control": "no-store"})


async def _body(request: web.Request) -> dict:
    try:
        data = await request.json()
    except web.HTTPRequestEntityTooLarge:
        raise ApiError(413, "too_large")
    except Exception:
        raise ApiError(400, "bad_json")
    if not isinstance(data, dict):
        raise ApiError(400, "bad_json")
    return data


def _int(data: dict, key: str) -> int:
    value = data.get(key)
    if isinstance(value, bool) or not isinstance(value, int):
        raise ApiError(400, f"bad_{key}")
    return value


def _question_payload(q: dict) -> dict:
    """Savolni mijozga yuboradi (to'g'ri javobsiz!)."""
    return {
        "id": q["id"], "number": q["number"], "total": q["total"], "text": q["text"],
        "options": [q[f"option_{i}"] for i in range(1, 5)],
    }


@web.middleware
async def security_headers(request: web.Request, handler):
    response = await handler(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "no-referrer")
    if not request.path.startswith("/api/"):
        response.headers.setdefault("Content-Security-Policy", CSP)
    return response


@web.middleware
async def api_guard(request: web.Request, handler):
    """/api uchun: imzoni tekshirish, foydalanuvchini ro'yxatga olish, obunani tekshirish."""
    if not request.path.startswith("/api/"):
        return await handler(request)
    settings: Settings = request.app["settings"]
    try:
        header = request.headers.get("Authorization", "")
        if not header.startswith("tma "):
            raise ApiError(401, "no_auth")
        try:
            init = safe_parse_webapp_init_data(settings.bot_token, header[4:])
        except ValueError:
            raise ApiError(401, "bad_auth")
        if time.time() - init.auth_date.timestamp() > MAX_AUTH_AGE:
            raise ApiError(401, "expired")
        user = init.user
        if user is None or user.is_bot:
            raise ApiError(401, "no_user")

        async with get_db(settings.db_path) as db:
            full_name = " ".join(p for p in (user.first_name, user.last_name) if p) or "Foydalanuvchi"
            await user_service.register_user(db, user.id, full_name, user.username)
            if (
                settings.required_channels
                and user.id not in settings.admin_ids
                and request.path != "/api/subscription"
            ):
                missing = await request.app["checker"].missing_channels(request.app["bot"], user.id)
                if missing:
                    raise ApiError(403, "subscription", channels=missing)
            request["db"], request["user_id"] = db, user.id
            return await handler(request)
    except ApiError as err:
        return _reply({"error": err.code, **err.extra}, err.status)
    except web.HTTPException:
        raise
    except Exception:
        log.exception("Web App API xatosi: %s", request.path)
        return _reply({"error": "server"}, 500)


# ---------- sahifa ----------
async def index(request: web.Request) -> web.FileResponse:
    return web.FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})


async def healthz(request: web.Request) -> web.Response:
    return web.Response(text="ok")


# ---------- API ----------
async def bootstrap(request):
    topics = await content_service.list_topics(request["db"])
    return _reply({"topics": [{"id": t["id"], "title": t["title"]} for t in topics]})


async def lesson(request):
    try:
        topic_id = int(request.query.get("topic_id", ""))
    except ValueError:
        raise ApiError(400, "bad_topic_id")
    db = request["db"]
    topic = await content_service.get_topic(db, topic_id)
    lessons = await content_service.get_lessons(db, topic_id)
    if topic is None or not lessons:
        raise ApiError(404, "topic_not_found")
    return _reply({"title": topic["title"], "lessons": [
        {"summary": l["summary"], "example": l["practical_example"], "review": l["review_questions"]}
        for l in lessons]})


async def test_start(request):
    data, db, uid = await _body(request), request["db"], request["user_id"]
    topic = await content_service.get_topic(db, _int(data, "topic_id"))
    if topic is None:
        raise ApiError(404, "topic_not_found")
    attempt = await test_service.start_attempt(db, uid, topic["id"])
    if attempt is None:
        raise ApiError(404, "no_questions")
    row = await test_service.get_attempt(db, attempt["id"], uid)
    question = await test_service.get_current_question(db, row)
    return _reply({"attempt_id": attempt["id"], "topic_id": topic["id"], "question": _question_payload(question)})


async def test_answer(request):
    data, db, uid = await _body(request), request["db"], request["user_id"]
    # Avval hamma maydon tekshiriladi (400), keyin bazadan qidiriladi (404)
    attempt_id, question_id, option = _int(data, "attempt_id"), _int(data, "question_id"), _int(data, "option")
    attempt = await test_service.get_attempt(db, attempt_id, uid)
    if attempt is None:
        raise ApiError(404, "attempt_not_found")
    result = await test_service.submit_answer(db, attempt, question_id, option)
    if result is None:
        raise ApiError(409, "stale")
    question = result["question"]
    has_next = await test_service.get_current_question(db, attempt) is not None
    return _reply({
        "is_correct": result["is_correct"], "correct_option": question["correct_option"],
        "explanation": question["explanation"], "has_next": has_next,
    })


async def test_next(request):
    data, db, uid = await _body(request), request["db"], request["user_id"]
    attempt = await test_service.get_attempt(db, _int(data, "attempt_id"), uid)
    if attempt is None or attempt["status"] == "abandoned":
        raise ApiError(404, "attempt_not_found")
    if attempt["status"] == "in_progress":
        question = await test_service.get_current_question(db, attempt)
        if question is not None:
            return _reply({"question": _question_payload(question)})
    return _reply({"result": await test_service.finish_attempt(db, attempt["id"], uid)})


async def profile(request):
    stats = await user_service.get_profile_stats(request["db"], request["user_id"])
    user = stats["user"]
    return _reply({
        "name": user["full_name"], "registered": user["registered_at"][:10],
        "tests_taken": user["tests_taken"], "total_score": user["total_score"],
        "best_percent": user["best_percent"], "average": stats["average"],
        "mastered": [m["title"] for m in stats["mastered"]],
        "recent": [{
            "title": r["title"], "score": r["score"], "total": r["total"],
            "percent": test_service.calc_percent(r["score"], r["total"]),
            "date": (r["finished_at"] or "")[:10]} for r in stats["recent"]],
    })


async def leaderboard(request):
    db, uid = request["db"], request["user_id"]
    top = await user_service.get_leaderboard(db)
    return _reply({
        # Maxfiylik: faqat qisqartirilgan ism va ball
        "top": [{"place": i, "name": r["full_name"][:20], "score": r["total_score"]}
                for i, r in enumerate(top, start=1)],
        "rank": await user_service.get_user_rank(db, uid),
    })


async def subscription(request):
    checker: SubscriptionChecker = request.app["checker"]
    missing = []
    if request["user_id"] not in request.app["settings"].admin_ids:
        missing = await checker.missing_channels(request.app["bot"], request["user_id"], use_cache=False)
    return _reply({"missing": missing})


def create_app(settings: Settings, bot: Bot, checker: SubscriptionChecker) -> web.Application:
    app = web.Application(middlewares=[security_headers, api_guard], client_max_size=16 * 1024)
    app["settings"], app["bot"], app["checker"] = settings, bot, checker
    app.add_routes([
        web.get("/", index),
        web.get("/healthz", healthz),
        web.static("/static", STATIC_DIR, follow_symlinks=False),
        web.get("/api/bootstrap", bootstrap),
        web.get("/api/lesson", lesson),
        web.post("/api/test/start", test_start),
        web.post("/api/test/answer", test_answer),
        web.post("/api/test/next", test_next),
        web.get("/api/profile", profile),
        web.get("/api/leaderboard", leaderboard),
        web.post("/api/subscription", subscription),
    ])
    return app


async def start_webapp(settings: Settings, bot: Bot, checker: SubscriptionChecker) -> web.AppRunner:
    runner = web.AppRunner(create_app(settings, bot, checker), access_log=None)
    await runner.setup()
    await web.TCPSite(runner, settings.webapp_host, settings.webapp_port).start()
    log.info("Web App serveri: http://%s:%s (ommaviy manzil: %s)",
             settings.webapp_host, settings.webapp_port, settings.webapp_url)
    return runner
