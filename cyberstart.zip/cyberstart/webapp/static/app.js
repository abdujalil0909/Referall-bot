"use strict";
const tg = window.Telegram && window.Telegram.WebApp;
if (tg) { tg.ready(); tg.expand(); }
const app = document.getElementById("app");
const tabsEl = document.getElementById("tabs");
const TABS = [
  ["learn", "🛡️", "O’rganish"], ["tests", "📝", "Test"], ["profile", "📊", "Natijalar"],
  ["rank", "🏆", "Reyting"], ["about", "ℹ️", "Haqida"],
];
let topics = [], current = "learn", backFn = null, T = null, token = 0;

/* Xavfsiz DOM yaratish: matn har doim textNode sifatida qo'shiladi (XSS yo'q). */
function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (k === "class") e.className = v;
    else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else e.setAttribute(k, v);
  }
  for (const c of kids.flat()) if (c != null) e.append(c.nodeType ? c : document.createTextNode(String(c)));
  return e;
}
function show(...nodes) { app.replaceChildren(...nodes); window.scrollTo(0, 0); }
function buzz(kind) { if (tg && tg.HapticFeedback) tg.HapticFeedback.notificationOccurred(kind); }
function setBack(fn) {
  backFn = fn;
  if (!tg || !tg.BackButton) return;
  fn ? tg.BackButton.show() : tg.BackButton.hide();
}
if (tg && tg.BackButton) tg.BackButton.onClick(() => backFn && backFn());

async function api(path, body) {
  const res = await fetch(path, {
    method: body ? "POST" : "GET",
    headers: { Authorization: "tma " + (tg ? tg.initData : ""), "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = {};
  try { data = await res.json(); } catch (_) { /* bo'sh javob */ }
  if (!res.ok) { const e = new Error(data.error || "http_" + res.status); e.code = data.error; e.data = data; throw e; }
  return data;
}

/* Barcha ekranlar shu orqali: xatolar bir joyda boshqariladi. */
async function run(fn) {
  const my = ++token;
  try { await fn(); } catch (e) {
    if (my !== token) return;
    setBack(null);
    if (e.code === "subscription") return subscribeView(e.data.channels || []);
    if (["no_auth", "bad_auth", "expired", "no_user"].includes(e.code))
      return show(h("h1", {}, "Telegram ichida oching"), h("p", { class: "mu" }, "Bu sahifa faqat CyberStart botidagi “🌐 Web App” tugmasi orqali ishlaydi."));
    show(h("h1", {}, "Xatolik yuz berdi"), h("p", { class: "mu" }, "Aloqani tekshirib, qayta urinib ko’ring."),
      h("button", { class: "btn main", onclick: () => go(current) }, "Qayta urinish"));
  }
}

function subscribeView(channels) {
  show(h("h1", {}, "Obuna bo’ling"),
    h("p", { class: "mu" }, "Botdan foydalanish uchun quyidagi kanallarga obuna bo’ling, so’ng “Tekshirish” tugmasini bosing."),
    h("div", { class: "list" }, channels.map(ch => h("button", { class: "btn", onclick: () => {
      const url = "https://t.me/" + ch.replace(/^@/, "");
      tg && tg.openTelegramLink ? tg.openTelegramLink(url) : window.open(url, "_blank", "noopener");
    } }, "📢 " + ch))),
    h("div", { class: "row" }, h("button", { class: "btn main", onclick: async () => {
      try {
        const r = await api("/api/subscription", {});
        if (r.missing.length) { buzz("error"); subscribeView(r.missing); } else { buzz("success"); boot(); }
      } catch (_) { boot(); }
    } }, "✅ Tekshirish")));
}

/* ---------- O'rganish ---------- */
function topicList(title, onPick) {
  return [h("h1", {}, title), h("div", { class: "list" },
    topics.map((t, i) => h("button", { class: "btn", onclick: () => onPick(t) }, (i + 1) + ". " + t.title)))];
}
function learn() { setBack(null); show(...topicList("🛡️ O’rganish", t => run(() => lessonView(t.id)))); }
async function lessonView(id, page = 0) {
  const d = await api("/api/lesson?topic_id=" + id);
  const l = d.lessons[page];
  setBack(learn);
  show(h("h1", {}, d.title),
    d.lessons.length > 1 ? h("p", { class: "mu" }, "Dars " + (page + 1) + "/" + d.lessons.length) : null,
    h("h2", {}, "📖 Qisqacha tushuntirish"), h("div", { class: "card" }, l.summary),
    h("h2", {}, "🧪 Amaliy misol"), h("pre", { class: "card" }, l.example),
    h("h2", {}, "❓ Bilimni tekshirish uchun savollar"), h("div", { class: "card" }, l.review),
    d.lessons.length > 1 ? h("div", { class: "row" },
      h("button", { class: "btn", disabled: page === 0 ? "" : null, onclick: () => run(() => lessonView(id, page - 1)) }, "◀️"),
      h("button", { class: "btn", disabled: page === d.lessons.length - 1 ? "" : null, onclick: () => run(() => lessonView(id, page + 1)) }, "▶️")) : null,
    h("div", { class: "row" }, h("button", { class: "btn main", onclick: () => run(() => startTest(id)) }, "📝 Shu mavzu bo’yicha test")));
}

/* ---------- Test ---------- */
function tests() { setBack(null); T = null; show(...topicList("📝 Test ishlash", t => run(() => startTest(t.id)))); }
async function startTest(topicId) {
  const d = await api("/api/test/start", { topic_id: topicId });
  T = { attempt: d.attempt_id, topicId };
  question(d.question);
}
function question(q) {
  const bar = h("div", {}), btns = [];
  const box = h("div", { class: "list" });
  const info = h("div", {});
  q.options.forEach((text, i) => {
    const b = h("button", { class: "btn", onclick: () => choose(i + 1) }, (i + 1) + ". " + text);
    btns.push(b); box.append(b);
  });
  setBack(tests);
  show(h("p", { class: "mu" }, "Savol " + q.number + "/" + q.total),
    h("div", { class: "bar" }, bar), h("h1", {}, q.text), box, info);
  bar.style.width = Math.round(100 * (q.number - 1) / q.total) + "%";
  let busy = false;
  async function choose(option) {
    if (busy) return; busy = true;
    btns.forEach(b => b.disabled = true);
    try {
      const r = await api("/api/test/answer", { attempt_id: T.attempt, question_id: q.id, option });
      btns[r.correct_option - 1].classList.add("right");
      if (!r.is_correct) btns[option - 1].classList.add("wrong");
      buzz(r.is_correct ? "success" : "error");
      info.replaceChildren(
        h("p", { class: r.is_correct ? "ok" : "no" }, r.is_correct ? "✅ To’g’ri!" : "❌ Noto’g’ri. To’g’ri javob: " + r.correct_option),
        h("div", { class: "card" }, "💡 " + r.explanation),
        h("div", { class: "row" }, h("button", { class: "btn main", onclick: () => run(next) },
          r.has_next ? "➡️ Keyingi savol" : "🏁 Natijani ko’rish")));
      bar.style.width = Math.round(100 * q.number / q.total) + "%";
    } catch (e) {
      if (e.code === "stale") return run(next);   // eskirgan savol: holatni qayta tiklaymiz
      throw e;
    }
  }
}
async function next() {
  const d = await api("/api/test/next", { attempt_id: T.attempt });
  if (d.question) return question(d.question);
  const r = d.result, verdict = r.percent >= 80 ? "🎉 Ajoyib natija!" : r.percent >= 50 ? "👍 Yaxshi, yana mashq qiling." : "📚 Mavzuni qayta o’qib, yana urinib ko’ring.";
  setBack(tests); buzz("success");
  show(h("h1", {}, "🏁 Test yakunlandi"), h("p", { class: "mu" }, r.topic_title),
    h("div", { class: "big" }, r.score + "/" + r.total), h("p", {}, "Foiz: " + r.percent + "%"), h("p", {}, verdict),
    h("div", { class: "row" },
      h("button", { class: "btn main", onclick: () => run(() => startTest(r.topic_id)) }, "🔁 Qayta ishlash"),
      h("button", { class: "btn", onclick: tests }, "📝 Boshqa mavzu")));
}

/* ---------- Natijalar ---------- */
async function profile() {
  setBack(null);
  const p = await api("/api/profile");
  show(h("h1", {}, "📊 Mening natijalarim"), h("p", { class: "mu" }, p.name + " · " + p.registered),
    h("dl", {}, h("dt", {}, "Ishlangan testlar"), h("dd", {}, p.tests_taken), h("dt", {}, "To’plangan ball"), h("dd", {}, p.total_score),
      h("dt", {}, "O’rtacha natija"), h("dd", {}, p.average + "%"), h("dt", {}, "Eng yaxshi natija"), h("dd", {}, p.best_percent + "%")),
    h("h2", {}, "✅ O’zlashtirilgan mavzular (80%+)"),
    h("div", { class: "card" }, p.mastered.length ? p.mastered.join(", ") : "Hali yo’q"),
    h("h2", {}, "🕘 Oxirgi testlar"),
    p.recent.length ? h("div", { class: "list" }, p.recent.map(r =>
      h("div", { class: "card" }, r.title + ": " + r.score + "/" + r.total + " (" + r.percent + "%) · " + r.date))) : h("p", { class: "mu" }, "Hali test ishlanmagan."));
}

/* ---------- Reyting ---------- */
async function rank() {
  setBack(null);
  const d = await api("/api/leaderboard"), medal = ["🥇", "🥈", "🥉"];
  show(h("h1", {}, "🏆 Eng yaxshi 10 nafar"),
    d.top.length ? h("ol", { class: "rank" }, d.top.map(r =>
      h("li", {}, h("span", {}, (medal[r.place - 1] || r.place + ".") + " " + r.name), h("b", {}, r.score + " ball"))))
      : h("p", { class: "mu" }, "Reyting hozircha bo’sh. Birinchi bo’lib test ishlang!"),
    h("p", {}, d.rank ? "📍 Sizning o’rningiz: " + d.rank : "📍 Reytingga kirish uchun kamida bitta test ishlang."),
    h("p", { class: "mu" }, "Ball teng bo’lsa: yuqori eng yaxshi natija, so’ng erta ro’yxatdan o’tgan yuqorida."));
}

/* ---------- Loyiha haqida ---------- */
function about() {
  setBack(null);
  show(h("h1", {}, "ℹ️ CyberStart haqida"),
    h("p", {}, "CyberStart — axborot xavfsizligini o’zbek tilida noldan o’rgatadigan loyiha."),
    h("div", { class: "card" }, "• 8 ta mavzu bo’yicha o’quv materiallari;\n• har bir mavzu bo’yicha 10 savollik test;\n• natijalaringizni kuzatish va reyting."),
    h("p", { class: "mu" }, "Barcha materiallar faqat qonuniy va himoyaga yo’naltirilgan."));
}

/* ---------- Tab bar ---------- */
const VIEWS = { learn, tests, profile, rank, about };
function go(name) {
  current = name;
  [...tabsEl.children].forEach(b => b.classList.toggle("on", b.dataset.t === name));
  run(VIEWS[name]);
}
TABS.forEach(([name, icon, label]) => tabsEl.append(
  h("button", { "data-t": name, onclick: () => go(name) }, h("span", {}, icon), label)));

async function boot() {
  await run(async () => { topics = (await api("/api/bootstrap")).topics; });
  if (topics.length) go(current);
}
boot();
