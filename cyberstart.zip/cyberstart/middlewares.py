"""Middleware'lar: baza ulanishi va majburiy obuna."""
from aiogram import BaseMiddleware
from aiogram.enums import ChatType
from aiogram.types import CallbackQuery, Message

from config import Settings
from database import get_db
from keyboards.inline import subscribe_kb
from services.subscription_service import SubscriptionChecker
from services.user_service import register_user

PROMPT = (
    "📢 Botdan foydalanish uchun quyidagi kanallarga obuna bo'ling, "
    "so'ng \"✅ Tekshirish\" tugmasini bosing."
)


class DbMiddleware(BaseMiddleware):
    """Har bir yangilanish uchun bazaga ulanish ochadi va foydalanuvchini ro'yxatga oladi."""

    def __init__(self, settings: Settings):
        self.settings = settings

    async def __call__(self, handler, event, data):
        if isinstance(event, Message) and event.chat.type != ChatType.PRIVATE:
            return await handler(event, data)  # guruh xabarlari ishlanmaydi
        user = data.get("event_from_user")
        async with get_db(self.settings.db_path) as db:
            data["db"] = db
            if user is not None and not user.is_bot:
                await register_user(db, user.id, user.full_name, user.username)
            return await handler(event, data)


class SubscriptionMiddleware(BaseMiddleware):
    """Majburiy kanallarga a'zo bo'lmagan foydalanuvchini to'xtatadi.

    O'tkazib yuboriladi: obuna o'chiq bo'lsa, adminlar, guruh xabarlari va
    "sub:check" tugmasi (uni start.py dagi handler o'zi keshsiz tekshiradi).
    """

    def __init__(self, settings: Settings, checker: SubscriptionChecker):
        self.settings = settings
        self.checker = checker

    async def __call__(self, handler, event, data):
        user = data.get("event_from_user")
        if (
            not self.checker.enabled
            or user is None
            or user.is_bot
            or user.id in self.settings.admin_ids
            or (isinstance(event, Message) and event.chat.type != ChatType.PRIVATE)
            or (isinstance(event, CallbackQuery) and event.data == "sub:check")
        ):
            return await handler(event, data)

        missing = await self.checker.missing_channels(data["bot"], user.id)
        if not missing:
            return await handler(event, data)

        if isinstance(event, Message):
            await event.answer(PROMPT, reply_markup=subscribe_kb(missing))
        elif isinstance(event, CallbackQuery):
            await event.answer("Avval kanallarga obuna bo'ling.", show_alert=True)
            if isinstance(event.message, Message):
                await event.message.answer(PROMPT, reply_markup=subscribe_kb(missing))
        return None
