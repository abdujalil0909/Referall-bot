"""/start, "Loyiha haqida", menyuga qaytish va nomaʼlum xabarlar."""
from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from config import Settings
from handlers.common import esc
from keyboards.inline import webapp_kb
from keyboards.main_menu import BTN_ABOUT, BTN_WEBAPP, main_menu_kb
from services.subscription_service import SubscriptionChecker

router = Router(name="start")
# Eng oxirida ulanadi: boshqa hech kim ushlamagan xabarlarni qabul qiladi
fallback_router = Router(name="fallback")

ABOUT_TEXT = (
    "ℹ️ <b>CyberStart haqida</b>\n\n"
    "CyberStart — axborot xavfsizligini o'zbek tilida noldan o'rgatadigan loyiha.\n"
    "Bu bot orqali siz:\n"
    "• 8 ta mavzu bo'yicha o'quv materiallarini o'qiysiz;\n"
    "• har bir mavzu bo'yicha 10 savollik test ishlaysiz;\n"
    "• natijalaringizni kuzatib, reytingda o'rningizni ko'rasiz.\n\n"
    "Barcha materiallar faqat qonuniy va himoyaga yo'naltirilgan."
)


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    name = esc(message.from_user.first_name or "do'st")
    await message.answer(
        f"👋 Salom, <b>{name}</b>!\n\n"
        "🛡️ <b>CyberStart</b> botiga xush kelibsiz.\n"
        "Bilimni noldan boshlaymiz, xavfsizlikni amalda o'rganamiz.\n\n"
        "Quyidagi menyudan tanlang 👇",
        reply_markup=main_menu_kb(),
    )


@router.message(Command("cancel"))
async def cmd_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("Bekor qilindi.", reply_markup=main_menu_kb())


@router.message(F.text == BTN_ABOUT)
async def show_about(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(ABOUT_TEXT, reply_markup=main_menu_kb())


@router.message(Command("app"))
@router.message(F.text == BTN_WEBAPP)
async def open_webapp(message: Message, state: FSMContext, settings: Settings) -> None:
    await state.clear()
    if not settings.webapp_url:
        await message.answer("Web App hozircha sozlanmagan.")
        return
    await message.answer(
        "🌐 Web App’ni ochish uchun tugmani bosing 👇", reply_markup=webapp_kb(settings.webapp_url)
    )


@router.callback_query(F.data == "menu")
async def back_to_menu(cb: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    if isinstance(cb.message, Message):
        await cb.message.answer("🏠 Asosiy menyu", reply_markup=main_menu_kb())
    await cb.answer()


@router.callback_query(F.data == "sub:check")
async def check_subscription(cb: CallbackQuery, bot: Bot, subscription: SubscriptionChecker) -> None:
    missing = await subscription.missing_channels(bot, cb.from_user.id, use_cache=False)
    if missing:
        await cb.answer("Hali obuna bo'lmagansiz: " + ", ".join(missing), show_alert=True)
        return
    await cb.answer("✅ Rahmat!")
    if isinstance(cb.message, Message):
        await cb.message.answer(
            "✅ Obuna tasdiqlandi. Menyudan tanlang 👇", reply_markup=main_menu_kb()
        )


@router.callback_query(F.data == "noop")
async def noop(cb: CallbackQuery) -> None:
    await cb.answer()


# ---------- fallback ----------
@fallback_router.message(Command("admin"))
async def admin_denied(message: Message) -> None:
    """Admin routeri adminlarni o'zi ushlaydi; bu yerga faqat oddiy foydalanuvchilar tushadi."""
    await message.answer("⛔ Bu buyruq faqat administratorlar uchun.")


@fallback_router.callback_query()
async def stale_or_denied(cb: CallbackQuery, settings: Settings) -> None:
    if (cb.data or "").startswith("adm:") and cb.from_user.id not in settings.admin_ids:
        await cb.answer("⛔ Ruxsat yo'q", show_alert=True)
    else:
        await cb.answer("Bu tugma eskirgan. Menyudan qayta boshlang.")


@fallback_router.message()
async def unknown_message(message: Message) -> None:
    await message.answer("Menyudan kerakli tugmani tanlang 👇", reply_markup=main_menu_kb())
