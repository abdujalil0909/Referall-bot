"""Handlerlar uchun umumiy yordamchi funksiyalar."""
import html

from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery, InlineKeyboardMarkup, Message


def esc(value) -> str:
    """Foydalanuvchi yoki baza matnini HTML uchun xavfsiz qiladi."""
    return html.escape(str(value), quote=False)


def parse_ints(data: str, count: int) -> list[int] | None:
    """'x:1:2' kabi callback ma'lumotidan 'x' dan keyingi `count` ta butun sonni oladi."""
    parts = data.split(":")[1:]
    if len(parts) != count:
        return None
    try:
        return [int(p) for p in parts]
    except ValueError:
        return None


async def edit_or_send(
    cb: CallbackQuery, text: str, reply_markup: InlineKeyboardMarkup | None = None
) -> None:
    """Xabarni tahrirlaydi; imkon bo'lmasa yangi xabar yuboradi."""
    if not isinstance(cb.message, Message):
        return
    try:
        await cb.message.edit_text(text, reply_markup=reply_markup)
    except TelegramBadRequest as exc:
        if "message is not modified" in str(exc):
            return
        await cb.message.answer(text, reply_markup=reply_markup)
