"""Administrator paneli. Router darajasidagi IsAdmin filtri har bir amalda ishlaydi,
servis funksiyalari esa huquqni yana bir bor tekshiradi."""
import aiosqlite
from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

from config import Settings
from filters import IsAdmin
from handlers.common import edit_or_send, esc
from keyboards.inline import (
    NUMBERS, admin_back_kb, admin_menu_kb, confirm_delete_kb, correct_option_kb,
    question_detail_kb, question_list_kb, topics_kb,
)
from services import admin_service, content_service
from services.validators import FIELD_LIMITS, clean_text, parse_field_value

router = Router(name="admin")
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())

PANEL_TEXT = "🛠 <b>Admin paneli</b>"
CANCEL_HINT = "\n\n<i>Bekor qilish: /cancel</i>"

FIELD_NAMES = {
    "text": "savol matni", "explanation": "izoh", "correct_option": "to'g'ri javob raqami (1-4)",
    "option_1": "1-variant", "option_2": "2-variant", "option_3": "3-variant", "option_4": "4-variant",
}


class AddLesson(StatesGroup):
    summary = State()
    example = State()
    review = State()


class AddQuestion(StatesGroup):
    text = State()
    options = State()
    correct = State()
    explanation = State()


class EditQuestion(StatesGroup):
    value = State()


def _question_text(q: dict) -> str:
    lines = [f"❓ <b>Savol #{q['id']}</b>\n\n{esc(q['text'])}\n"]
    for i in range(1, 5):
        mark = " ✅" if q["correct_option"] == i else ""
        lines.append(f"{NUMBERS[i - 1]} {esc(q[f'option_{i}'])}{mark}")
    lines.append(f"\n💡 {esc(q['explanation'])}")
    return "\n".join(lines)


# ---------- menyu ----------
@router.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer(PANEL_TEXT, reply_markup=admin_menu_kb())


@router.callback_query(F.data == "adm:menu")
async def cb_menu(cb: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await edit_or_send(cb, PANEL_TEXT, admin_menu_kb())
    await cb.answer()


@router.callback_query(F.data == "adm:users")
async def cb_users(cb: CallbackQuery, db: aiosqlite.Connection, settings: Settings) -> None:
    stats = await admin_service.get_bot_stats(db, settings.admin_ids, cb.from_user.id)
    await edit_or_send(cb, f"👥 Foydalanuvchilar soni: <b>{stats['users']}</b>", admin_back_kb())
    await cb.answer()


@router.callback_query(F.data == "adm:stats")
async def cb_stats(cb: CallbackQuery, db: aiosqlite.Connection, settings: Settings) -> None:
    s = await admin_service.get_bot_stats(db, settings.admin_ids, cb.from_user.id)
    text = (
        "📈 <b>Bot statistikasi</b>\n\n"
        f"👥 Foydalanuvchilar: <b>{s['users']}</b> (24 soatda +{s['new_users_24h']})\n"
        f"🗂 Mavzular: {s['topics']}\n📚 Darslar: {s['lessons']}\n❓ Savollar: {s['questions']}\n"
        f"📝 Yakunlangan testlar: <b>{s['finished_tests']}</b> (24 soatda {s['tests_24h']})\n"
        f"📊 O'rtacha natija: {s['average_percent']}%"
    )
    await edit_or_send(cb, text, admin_back_kb())
    await cb.answer()


# ---------- o'quv materiali qo'shish ----------
@router.callback_query(F.data == "adm:al")
async def cb_add_lesson_topics(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    topics = await content_service.list_topics(db)
    await edit_or_send(cb, "➕ Qaysi mavzuga dars qo'shamiz?", topics_kb(topics, "adm:alt", "adm:menu"))
    await cb.answer()


@router.callback_query(F.data.startswith("adm:alt:"))
async def cb_add_lesson_start(cb: CallbackQuery, state: FSMContext) -> None:
    try:
        topic_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    await state.set_state(AddLesson.summary)
    await state.update_data(topic_id=topic_id)
    await edit_or_send(cb, "1/3. <b>Qisqacha tushuntirish</b> matnini yuboring (1500 belgigacha)." + CANCEL_HINT)
    await cb.answer()


@router.message(AddLesson.summary)
async def lesson_summary(message: Message, state: FSMContext) -> None:
    value = clean_text(message.text, 1500)
    if value is None:
        await message.answer("Matn bo'sh yoki 1500 belgidan uzun. Qayta yuboring." + CANCEL_HINT)
        return
    await state.update_data(summary=value)
    await state.set_state(AddLesson.example)
    await message.answer("2/3. <b>Amaliy misol</b> matnini yuboring (1000 belgigacha)." + CANCEL_HINT)


@router.message(AddLesson.example)
async def lesson_example(message: Message, state: FSMContext) -> None:
    value = clean_text(message.text, 1000)
    if value is None:
        await message.answer("Matn bo'sh yoki 1000 belgidan uzun. Qayta yuboring." + CANCEL_HINT)
        return
    await state.update_data(example=value)
    await state.set_state(AddLesson.review)
    await message.answer("3/3. <b>Bilimni tekshirish savollari</b> (har biri yangi qatorda, 800 belgigacha)." + CANCEL_HINT)


@router.message(AddLesson.review)
async def lesson_review(
    message: Message, state: FSMContext, db: aiosqlite.Connection, settings: Settings
) -> None:
    value = clean_text(message.text, 800)
    if value is None:
        await message.answer("Matn bo'sh yoki 800 belgidan uzun. Qayta yuboring." + CANCEL_HINT)
        return
    data = await state.get_data()
    lesson_id = await admin_service.add_lesson(
        db, settings.admin_ids, message.from_user.id,
        data["topic_id"], data["summary"], data["example"], value,
    )
    await state.clear()
    await message.answer(f"✅ Dars qo'shildi (ID: {lesson_id}).", reply_markup=admin_menu_kb())


# ---------- test savoli qo'shish ----------
@router.callback_query(F.data == "adm:aq")
async def cb_add_question_topics(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    topics = await content_service.list_topics(db)
    await edit_or_send(cb, "➕ Qaysi mavzuga savol qo'shamiz?", topics_kb(topics, "adm:aqt", "adm:menu"))
    await cb.answer()


@router.callback_query(F.data.startswith("adm:aqt:"))
async def cb_add_question_start(cb: CallbackQuery, state: FSMContext) -> None:
    try:
        topic_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    await state.set_state(AddQuestion.text)
    await state.update_data(topic_id=topic_id)
    await edit_or_send(cb, "1/4. <b>Savol matnini</b> yuboring (300 belgigacha)." + CANCEL_HINT)
    await cb.answer()


@router.message(AddQuestion.text)
async def question_text(message: Message, state: FSMContext) -> None:
    value = clean_text(message.text, FIELD_LIMITS["text"])
    if value is None:
        await message.answer("Matn bo'sh yoki 300 belgidan uzun. Qayta yuboring." + CANCEL_HINT)
        return
    await state.update_data(text=value)
    await state.set_state(AddQuestion.options)
    await message.answer("2/4. <b>4 ta variantni</b> yuboring, har biri yangi qatorda." + CANCEL_HINT)


@router.message(AddQuestion.options)
async def question_options(message: Message, state: FSMContext) -> None:
    raw = message.text or ""
    lines = [clean_text(line, FIELD_LIMITS["option_1"]) for line in raw.splitlines() if line.strip()]
    if len(lines) != 4 or any(line is None for line in lines):
        await message.answer("Aynan 4 ta qator kerak (har biri 150 belgigacha). Qayta yuboring." + CANCEL_HINT)
        return
    await state.update_data(options=lines)
    await state.set_state(AddQuestion.correct)
    listing = "\n".join(f"{NUMBERS[i]} {esc(lines[i])}" for i in range(4))
    await message.answer(f"3/4. <b>To'g'ri javobni</b> tanlang:\n\n{listing}", reply_markup=correct_option_kb())


@router.callback_query(AddQuestion.correct, F.data.startswith("adm:qc:"))
async def question_correct(cb: CallbackQuery, state: FSMContext) -> None:
    try:
        number = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        number = 0
    if number not in (1, 2, 3, 4):
        await cb.answer("Noto'g'ri tanlov", show_alert=True)
        return
    await state.update_data(correct=number)
    await state.set_state(AddQuestion.explanation)
    await edit_or_send(cb, "4/4. <b>Qisqa izoh</b> yuboring (300 belgigacha)." + CANCEL_HINT)
    await cb.answer()


@router.message(AddQuestion.explanation)
async def question_explanation(
    message: Message, state: FSMContext, db: aiosqlite.Connection, settings: Settings
) -> None:
    value = clean_text(message.text, FIELD_LIMITS["explanation"])
    if value is None:
        await message.answer("Matn bo'sh yoki 300 belgidan uzun. Qayta yuboring." + CANCEL_HINT)
        return
    data = await state.get_data()
    question_id = await admin_service.add_question(
        db, settings.admin_ids, message.from_user.id,
        data["topic_id"], data["text"], data["options"], data["correct"], value,
    )
    await state.clear()
    await message.answer(f"✅ Savol qo'shildi (ID: {question_id}).", reply_markup=admin_menu_kb())


# ---------- savollarni tahrirlash va o'chirish ----------
@router.callback_query(F.data == "adm:mq")
async def cb_manage_topics(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    topics = await content_service.list_topics(db)
    await edit_or_send(cb, "✏️ Qaysi mavzu savollari?", topics_kb(topics, "adm:mqt", "adm:menu"))
    await cb.answer()


async def _show_question_list(cb: CallbackQuery, db, settings, topic_id: int, page: int) -> None:
    questions, total = await admin_service.list_questions(
        db, settings.admin_ids, cb.from_user.id, topic_id, page
    )
    if total == 0:
        await edit_or_send(cb, "Bu mavzuda savol yo'q.", admin_back_kb())
        return
    page_size = admin_service.PAGE_SIZE
    pages = (total + page_size - 1) // page_size
    await edit_or_send(
        cb, f"❓ Savollar: {total} ta (sahifa {page + 1}/{pages})",
        question_list_kb(topic_id, questions, page, total, page_size),
    )


@router.callback_query(F.data.startswith("adm:mqt:"))
async def cb_manage_list_first(cb: CallbackQuery, db: aiosqlite.Connection, settings: Settings) -> None:
    try:
        topic_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    await _show_question_list(cb, db, settings, topic_id, 0)
    await cb.answer()


@router.callback_query(F.data.startswith("adm:mql:"))
async def cb_manage_list_page(cb: CallbackQuery, db: aiosqlite.Connection, settings: Settings) -> None:
    try:
        _, _, topic_id, page = cb.data.split(":")
        topic_id, page = int(topic_id), int(page)
    except ValueError:
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    await _show_question_list(cb, db, settings, topic_id, page)
    await cb.answer()


@router.callback_query(F.data.startswith("adm:q:"))
async def cb_question_detail(cb: CallbackQuery, state: FSMContext, db: aiosqlite.Connection, settings: Settings) -> None:
    await state.clear()
    try:
        question_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    q = await admin_service.get_question(db, settings.admin_ids, cb.from_user.id, question_id)
    if q is None:
        await cb.answer("Savol topilmadi", show_alert=True)
        return
    await edit_or_send(cb, _question_text(q), question_detail_kb(q["id"], q["topic_id"]))
    await cb.answer()


@router.callback_query(F.data.startswith("adm:qe:"))
async def cb_edit_start(cb: CallbackQuery, state: FSMContext) -> None:
    try:
        _, _, question_id, field = cb.data.split(":")
        question_id = int(question_id)
    except ValueError:
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    if field not in admin_service.EDITABLE_FIELDS:
        await cb.answer("Bu maydonni tahrirlab bo'lmaydi", show_alert=True)
        return
    await state.set_state(EditQuestion.value)
    await state.update_data(question_id=question_id, field=field)
    await edit_or_send(cb, f"Yangi qiymatni yuboring: <b>{FIELD_NAMES[field]}</b>." + CANCEL_HINT)
    await cb.answer()


@router.message(EditQuestion.value)
async def edit_value(
    message: Message, state: FSMContext, db: aiosqlite.Connection, settings: Settings
) -> None:
    data = await state.get_data()
    value = parse_field_value(data["field"], message.text)
    if value is None:
        await message.answer("Qiymat noto'g'ri yoki juda uzun. Qayta yuboring." + CANCEL_HINT)
        return
    admin_id = message.from_user.id
    updated = await admin_service.update_question_field(
        db, settings.admin_ids, admin_id, data["question_id"], data["field"], value
    )
    await state.clear()
    if not updated:
        await message.answer("Savol topilmadi.", reply_markup=admin_menu_kb())
        return
    q = await admin_service.get_question(db, settings.admin_ids, admin_id, data["question_id"])
    await message.answer("✅ Yangilandi.\n\n" + _question_text(q), reply_markup=question_detail_kb(q["id"], q["topic_id"]))


@router.callback_query(F.data.startswith("adm:qd:"))
async def cb_delete_confirm(cb: CallbackQuery) -> None:
    try:
        question_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    await edit_or_send(cb, f"🗑 Savol #{question_id} o'chirilsinmi?", confirm_delete_kb(question_id))
    await cb.answer()


@router.callback_query(F.data.startswith("adm:qdy:"))
async def cb_delete_do(cb: CallbackQuery, db: aiosqlite.Connection, settings: Settings) -> None:
    try:
        question_id = int(cb.data.split(":")[2])
    except (IndexError, ValueError):
        await cb.answer("Noto'g'ri tugma", show_alert=True)
        return
    result = await admin_service.delete_question(db, settings.admin_ids, cb.from_user.id, question_id)
    if result is None:
        await cb.answer("Savol topilmadi", show_alert=True)
        return
    text = f"🗑 Savol #{question_id} o'chirildi. Mavzuda {result['remaining']} ta savol qoldi."
    if result["remaining"] < 10:
        text += "\n⚠️ Testda 10 tadan kam savol bo'ladi."
    await edit_or_send(cb, text, admin_back_kb())
    await cb.answer()
