"""Test ishlash bo'limi."""
import aiosqlite
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

from handlers.common import edit_or_send, esc, parse_ints
from keyboards.inline import NUMBERS, answer_kb, next_kb, result_kb, topics_kb
from keyboards.main_menu import BTN_TEST
from services import content_service, test_service

router = Router(name="tests")

TOPICS_TEXT = "📝 <b>Test ishlash</b>\nMavzuni tanlang (10 ta savol):"


def format_question(question: dict) -> str:
    options = "\n".join(
        f"{NUMBERS[i]} {esc(question[f'option_{i + 1}'])}" for i in range(4)
    )
    return f"<b>Savol {question['number']}/{question['total']}</b>\n\n{esc(question['text'])}\n\n{options}"


def format_result(result: dict) -> str:
    percent = result["percent"]
    if percent >= 80:
        verdict = "🎉 Ajoyib natija!"
    elif percent >= 50:
        verdict = "👍 Yaxshi, yana mashq qiling."
    else:
        verdict = "📚 Mavzuni qayta o'qib, yana urinib ko'ring."
    return (
        "🏁 <b>Test yakunlandi</b>\n\n"
        f"Mavzu: {esc(result['topic_title'])}\n"
        f"Jami ball: <b>{result['score']}/{result['total']}</b>\n"
        f"Foiz: <b>{percent}%</b>\n\n{verdict}"
    )


@router.message(F.text == BTN_TEST)
async def show_topics(message: Message, state: FSMContext, db: aiosqlite.Connection) -> None:
    await state.clear()
    topics = await content_service.list_topics(db)
    await message.answer(TOPICS_TEXT, reply_markup=topics_kb(topics, "tt"))


@router.callback_query(F.data == "tests")
async def back_to_topics(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    topics = await content_service.list_topics(db)
    await edit_or_send(cb, TOPICS_TEXT, topics_kb(topics, "tt"))
    await cb.answer()


@router.callback_query(F.data.startswith("tt:"))
async def start_test(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    ints = parse_ints(cb.data, 1)
    topic = await content_service.get_topic(db, ints[0]) if ints else None
    if topic is None:
        await cb.answer("Mavzu topilmadi", show_alert=True)
        return
    attempt = await test_service.start_attempt(db, cb.from_user.id, topic["id"])
    if attempt is None:
        await cb.answer("Bu mavzuda hali savol yo'q", show_alert=True)
        return
    attempt_row = await test_service.get_attempt(db, attempt["id"], cb.from_user.id)
    question = await test_service.get_current_question(db, attempt_row)
    await edit_or_send(
        cb,
        f"📝 <b>{esc(topic['title'])}</b>\n\n{format_question(question)}",
        answer_kb(attempt["id"], question["id"]),
    )
    await cb.answer()


@router.callback_query(F.data.startswith("a:"))
async def answer_question(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    ints = parse_ints(cb.data, 3)
    attempt = await test_service.get_attempt(db, ints[0], cb.from_user.id) if ints else None
    result = None
    if attempt is not None:
        result = await test_service.submit_answer(db, attempt, ints[1], ints[2])
    if result is None:
        await cb.answer("Bu savol allaqachon yopilgan yoki test tugagan.", show_alert=True)
        return
    question = result["question"]
    if result["is_correct"]:
        verdict = "✅ <b>To'g'ri!</b>"
    else:
        right = question["correct_option"]
        verdict = (
            f"❌ <b>Noto'g'ri.</b> To'g'ri javob: {NUMBERS[right - 1]} "
            f"{esc(question[f'option_{right}'])}"
        )
    is_last = await test_service.get_current_question(db, attempt) is None
    await edit_or_send(
        cb,
        f"{format_question(question)}\n\n{verdict}\n💡 {esc(question['explanation'])}",
        next_kb(attempt["id"], is_last),
    )
    await cb.answer()


@router.callback_query(F.data.startswith("n:"))
async def next_question(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    ints = parse_ints(cb.data, 1)
    attempt = await test_service.get_attempt(db, ints[0], cb.from_user.id) if ints else None
    if attempt is None or attempt["status"] == "abandoned":
        await cb.answer("Bu test endi mavjud emas. Yangisini boshlang.", show_alert=True)
        return
    question = None
    if attempt["status"] == "in_progress":
        question = await test_service.get_current_question(db, attempt)
    if question is not None:
        await edit_or_send(cb, format_question(question), answer_kb(attempt["id"], question["id"]))
    else:
        result = await test_service.finish_attempt(db, attempt["id"], cb.from_user.id)
        await edit_or_send(cb, format_result(result), result_kb(result["topic_id"]))
    await cb.answer()
