"""Reyting bo'limi."""
import aiosqlite
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from handlers.common import esc
from keyboards.main_menu import BTN_RANK
from services import user_service

router = Router(name="leaderboard")

MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}


@router.message(F.text == BTN_RANK)
async def show_leaderboard(message: Message, state: FSMContext, db: aiosqlite.Connection) -> None:
    await state.clear()
    top = await user_service.get_leaderboard(db)
    if not top:
        await message.answer("🏆 Reyting hozircha bo'sh. Birinchi bo'lib test ishlang!")
        return
    lines = ["🏆 <b>Eng yaxshi 10 nafar</b>\n"]
    for place, row in enumerate(top, start=1):
        # Maxfiylik: faqat qisqartirilgan ism ko'rsatiladi (ID va username yo'q)
        lines.append(
            f"{MEDALS.get(place, f'{place}.')} {esc(row['full_name'][:20])} — "
            f"<b>{row['total_score']}</b> ball"
        )
    rank = await user_service.get_user_rank(db, message.from_user.id)
    if rank is not None:
        lines.append(f"\n📍 Sizning o'rningiz: <b>{rank}</b>")
    else:
        lines.append("\n📍 Reytingga kirish uchun kamida bitta test ishlang.")
    lines.append("\n<i>Ball teng bo'lsa: yuqori eng yaxshi natija, so'ng erta ro'yxatdan o'tgan yuqorida.</i>")
    await message.answer("\n".join(lines))
