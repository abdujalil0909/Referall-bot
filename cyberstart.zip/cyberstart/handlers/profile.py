"""Mening natijalarim."""
import aiosqlite
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import Message

from handlers.common import esc
from keyboards.main_menu import BTN_RESULTS
from services import user_service
from services.test_service import calc_percent

router = Router(name="profile")


@router.message(F.text == BTN_RESULTS)
async def show_results(message: Message, state: FSMContext, db: aiosqlite.Connection) -> None:
    await state.clear()
    # Faqat so'rov yuborgan foydalanuvchining o'z ma'lumoti olinadi
    stats = await user_service.get_profile_stats(db, message.from_user.id)
    if stats is None:
        await message.answer("Avval /start ni bosing.")
        return
    user = stats["user"]
    lines = [
        "📊 <b>Mening natijalarim</b>\n",
        f"👤 {esc(user['full_name'])}",
        f"🗓 Ro'yxatdan o'tgan: {esc(user['registered_at'][:10])}",
        f"📝 Ishlangan testlar: <b>{user['tests_taken']}</b>",
        f"⭐ To'plangan ball: <b>{user['total_score']}</b>",
        f"📈 O'rtacha natija: <b>{stats['average']}%</b>",
        f"🏅 Eng yaxshi natija: <b>{user['best_percent']}%</b>",
    ]
    if stats["mastered"]:
        mastered = ", ".join(esc(m["title"]) for m in stats["mastered"])
        lines.append(f"\n✅ <b>O'zlashtirilgan mavzular</b> (80%+):\n{mastered}")
    else:
        lines.append("\n✅ O'zlashtirilgan mavzular: hali yo'q (mavzuda 80%+ kerak)")
    if stats["recent"]:
        lines.append("\n🕘 <b>Oxirgi testlar</b>")
        for item in stats["recent"]:
            percent = calc_percent(item["score"], item["total"])
            date = esc((item["finished_at"] or "")[:10])
            lines.append(f"• {esc(item['title'])}: {item['score']}/{item['total']} ({percent}%) — {date}")
    await message.answer("\n".join(lines))
