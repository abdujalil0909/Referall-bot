"""O'rganish bo'limi: mavzular va darslar."""
from aiogram import F, Router
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message

import aiosqlite

from handlers.common import edit_or_send, esc, parse_ints
from keyboards.inline import lesson_kb, topics_kb
from keyboards.main_menu import BTN_LEARN
from services import content_service

router = Router(name="learning")

TOPICS_TEXT = "🛡️ <b>O'rganish</b>\nMavzuni tanlang:"


async def render_lesson(db: aiosqlite.Connection, topic_id: int, index: int):
    """(matn, klaviatura) qaytaradi; mavzu yoki dars topilmasa None."""
    topic = await content_service.get_topic(db, topic_id)
    lessons = await content_service.get_lessons(db, topic_id)
    if topic is None or not lessons:
        return None
    index = max(0, min(index, len(lessons) - 1))
    lesson = lessons[index]
    text = (
        f"📚 <b>{esc(topic['title'])}</b>\n\n"
        f"<b>📖 Qisqacha tushuntirish</b>\n{esc(lesson['summary'])}\n\n"
        f"<b>🧪 Amaliy misol</b>\n{esc(lesson['practical_example'])}\n\n"
        f"<b>❓ Bilimni tekshirish uchun savollar</b>\n{esc(lesson['review_questions'])}"
    )
    return text, lesson_kb(topic_id, index, len(lessons))


@router.message(F.text == BTN_LEARN)
async def show_topics(message: Message, state: FSMContext, db: aiosqlite.Connection) -> None:
    await state.clear()
    topics = await content_service.list_topics(db)
    await message.answer(TOPICS_TEXT, reply_markup=topics_kb(topics, "lt"))


@router.callback_query(F.data == "learn")
async def back_to_topics(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    topics = await content_service.list_topics(db)
    await edit_or_send(cb, TOPICS_TEXT, topics_kb(topics, "lt"))
    await cb.answer()


@router.callback_query(F.data.startswith("lt:"))
async def open_topic(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    ints = parse_ints(cb.data, 1)
    rendered = await render_lesson(db, ints[0], 0) if ints else None
    if rendered is None:
        await cb.answer("Mavzu topilmadi", show_alert=True)
        return
    await edit_or_send(cb, *rendered)
    await cb.answer()


@router.callback_query(F.data.startswith("l:"))
async def lesson_page(cb: CallbackQuery, db: aiosqlite.Connection) -> None:
    ints = parse_ints(cb.data, 2)
    rendered = await render_lesson(db, ints[0], ints[1]) if ints else None
    if rendered is None:
        await cb.answer("Dars topilmadi", show_alert=True)
        return
    await edit_or_send(cb, *rendered)
    await cb.answer()
