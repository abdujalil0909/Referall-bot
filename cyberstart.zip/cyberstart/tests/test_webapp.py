"""Web App serveri sinovlari: imzo tekshiruvi, API, xavfsizlik, obuna. Tarmoqsiz ishlaydi."""
import hashlib
import hmac
import json
import os
import tempfile
import time
import unittest
from urllib.parse import urlencode

from aiogram import Bot
from aiohttp.test_utils import TestClient, TestServer

from config import Settings
from database import get_db, init_db, seed_initial_content
from services import test_service
from services.subscription_service import SubscriptionChecker
from tests.test_flow import ADMIN, TOKEN, USER, FakeSession
from webapp.server import create_app


def sign(user_id: int, token: str = TOKEN, auth_date: float | None = None) -> str:
    """Telegram initData'ni rasmiy sxema bo'yicha imzolaydi (HMAC-SHA256)."""
    user = {"id": user_id, "first_name": "Ali", "username": f"u{user_id}"}
    fields = {
        "auth_date": str(int(auth_date if auth_date is not None else time.time())),
        "query_id": "AAHtest",
        "user": json.dumps(user, separators=(",", ":")),
    }
    check = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    fields["hash"] = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    return urlencode(fields)


def auth(user_id: int = USER, **kw) -> dict:
    return {"Authorization": "tma " + sign(user_id, **kw)}


class ApiTests(unittest.IsolatedAsyncioTestCase):
    channels: tuple = ()

    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "web.db")
        await init_db(self.db_path)
        await seed_initial_content(self.db_path)
        self.settings = Settings(TOKEN, frozenset({ADMIN}), self.db_path, self.channels, "https://example.com")
        self.session = FakeSession()
        bot = Bot(TOKEN, session=self.session)
        self.client = TestClient(TestServer(create_app(self.settings, bot, SubscriptionChecker(self.channels))))
        await self.client.start_server()

    async def asyncTearDown(self):
        await self.client.close()
        self.tmp.cleanup()

    async def get(self, path, user=USER, headers=None):
        return await self.client.get(path, headers=headers if headers is not None else auth(user))

    async def post(self, path, body, user=USER, headers=None, raw=None):
        kwargs = {"data": raw} if raw is not None else {"json": body}
        return await self.client.post(path, headers=headers if headers is not None else auth(user), **kwargs)

    async def current(self, user=USER):
        async with get_db(self.db_path) as db:
            cur = await db.execute(
                "SELECT * FROM test_attempts WHERE user_id=? AND status='in_progress' ORDER BY id DESC LIMIT 1", (user,))
            attempt = dict(await cur.fetchone())
            return attempt, await test_service.get_current_question(db, attempt)

    # ---------- sahifa va sarlavhalar ----------
    async def test_static_pages_and_headers(self):
        resp = await self.client.get("/")
        self.assertEqual(resp.status, 200)
        self.assertIn("telegram-web-app.js", await resp.text())
        self.assertIn("script-src 'self' https://telegram.org", resp.headers["Content-Security-Policy"])
        self.assertEqual(resp.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual((await self.client.get("/static/app.js")).status, 200)
        self.assertEqual((await self.client.get("/static/../config.py")).status, 404)
        self.assertEqual(await (await self.client.get("/healthz")).text(), "ok")

    # ---------- autentifikatsiya ----------
    async def test_auth_rejected(self):
        cases = {
            "no_auth": {},
            "bad_auth": {"Authorization": "tma " + sign(USER, token="999999999:" + "B" * 35)},
            "expired": auth(auth_date=time.time() - 3 * 24 * 3600),
        }
        for code, headers in cases.items():
            resp = await self.get("/api/bootstrap", headers=headers)
            self.assertEqual(resp.status, 401, code)
            self.assertEqual((await resp.json())["error"], code)
        # imzo to'g'ri, lekin foydalanuvchi ID'si almashtirilgan
        forged = sign(USER).replace(f"%22id%22%3A{USER}", f"%22id%22%3A{ADMIN}")
        self.assertNotEqual(forged, sign(USER))
        resp = await self.get("/api/bootstrap", headers={"Authorization": "tma " + forged})
        self.assertEqual(resp.status, 401)
        resp = await self.get("/api/bootstrap", headers={"Authorization": "Bearer abc"})
        self.assertEqual(resp.status, 401)

    async def test_bootstrap_registers_user(self):
        resp = await self.get("/api/bootstrap")
        data = await resp.json()
        self.assertEqual(len(data["topics"]), 8)
        async with get_db(self.db_path) as db:
            cur = await db.execute("SELECT full_name FROM users WHERE telegram_id=?", (USER,))
            self.assertEqual((await cur.fetchone())[0], "Ali")

    async def test_lesson(self):
        data = await (await self.get("/api/lesson?topic_id=1")).json()
        self.assertEqual(len(data["lessons"]), 1)
        self.assertIn("example", data["lessons"][0])
        self.assertEqual((await self.get("/api/lesson?topic_id=999")).status, 404)
        self.assertEqual((await self.get("/api/lesson?topic_id=abc")).status, 400)
        self.assertEqual((await self.get("/api/lesson")).status, 400)

    # ---------- test oqimi ----------
    async def test_full_test_flow_matches_bot_rules(self):
        resp = await self.post("/api/test/start", {"topic_id": 1})
        start = await resp.json()
        question = start["question"]
        # javob berilgunga qadar to'g'ri javob va izoh yuborilmaydi
        self.assertEqual(set(question), {"id", "number", "total", "text", "options"})
        self.assertEqual((question["number"], question["total"], len(question["options"])), (1, 10, 4))
        for number in range(1, 11):
            attempt, q = await self.current()
            self.assertEqual(q["number"], number)
            resp = await self.post("/api/test/answer", {
                "attempt_id": start["attempt_id"], "question_id": q["id"], "option": q["correct_option"]})
            answer = await resp.json()
            self.assertTrue(answer["is_correct"])
            self.assertEqual(answer["correct_option"], q["correct_option"])
            self.assertEqual(answer["has_next"], number < 10)
            # takroriy javob rad etiladi
            again = await self.post("/api/test/answer", {
                "attempt_id": start["attempt_id"], "question_id": q["id"], "option": 1})
            self.assertEqual((again.status, (await again.json())["error"]), (409, "stale"))
            nxt = await (await self.post("/api/test/next", {"attempt_id": start["attempt_id"]})).json()
            self.assertEqual("result" in nxt, number == 10)
        self.assertEqual((nxt["result"]["score"], nxt["result"]["percent"]), (10, 100))
        # takroriy "next" statistikani ikki marta oshirmaydi
        await self.post("/api/test/next", {"attempt_id": start["attempt_id"]})
        me = await (await self.get("/api/profile")).json()
        self.assertEqual((me["tests_taken"], me["total_score"], me["best_percent"]), (1, 10, 100))
        self.assertEqual(me["mastered"], ["Kiberxavfsizlikka kirish"])
        board = await (await self.get("/api/leaderboard")).json()
        self.assertEqual((board["rank"], board["top"][0]["score"]), (1, 10))
        self.assertEqual(set(board["top"][0]), {"place", "name", "score"})  # ID va username yo'q

    async def test_wrong_answer_and_next_before_answer(self):
        start = await (await self.post("/api/test/start", {"topic_id": 2})).json()
        _, q = await self.current()
        same = await (await self.post("/api/test/next", {"attempt_id": start["attempt_id"]})).json()
        self.assertEqual(same["question"]["id"], q["id"])  # javobsiz "next" savolni o'tkazib yubormaydi
        wrong = (q["correct_option"] % 4) + 1
        answer = await (await self.post("/api/test/answer", {
            "attempt_id": start["attempt_id"], "question_id": q["id"], "option": wrong})).json()
        self.assertFalse(answer["is_correct"])
        self.assertTrue(answer["explanation"])

    async def test_cannot_touch_other_users_attempt(self):
        start = await (await self.post("/api/test/start", {"topic_id": 1})).json()
        _, q = await self.current()
        body = {"attempt_id": start["attempt_id"], "question_id": q["id"], "option": 1}
        resp = await self.post("/api/test/answer", body, user=USER + 1)
        self.assertEqual(resp.status, 404)
        resp = await self.post("/api/test/next", {"attempt_id": start["attempt_id"]}, user=USER + 1)
        self.assertEqual(resp.status, 404)
        async with get_db(self.db_path) as db:
            cur = await db.execute("SELECT COUNT(*) FROM test_answers")
            self.assertEqual((await cur.fetchone())[0], 0)

    async def test_new_test_abandons_old_one(self):
        first = await (await self.post("/api/test/start", {"topic_id": 1})).json()
        await self.post("/api/test/start", {"topic_id": 2})
        resp = await self.post("/api/test/next", {"attempt_id": first["attempt_id"]})
        self.assertEqual(resp.status, 404)

    async def test_bad_input(self):
        for path, body in (("/api/test/start", {"topic_id": "1"}), ("/api/test/start", {"topic_id": True}),
                           ("/api/test/start", {}), ("/api/test/answer", {"attempt_id": 1}),
                           ("/api/test/next", {"attempt_id": 1.5})):
            resp = await self.post(path, body)
            self.assertEqual(resp.status, 400, (path, body))
        self.assertEqual((await self.post("/api/test/start", None, raw="{bad json")).status, 400)
        self.assertEqual((await self.post("/api/test/start", None, raw="[1,2]")).status, 400)
        self.assertEqual((await self.post("/api/test/start", {"topic_id": 999})).status, 404)
        start = await (await self.post("/api/test/start", {"topic_id": 1})).json()
        _, q = await self.current()
        resp = await self.post("/api/test/answer", {
            "attempt_id": start["attempt_id"], "question_id": q["id"], "option": 9})
        self.assertEqual(resp.status, 409)
        big = await self.post("/api/test/start", None, raw=json.dumps({"x": "a" * 20000}))
        self.assertEqual(big.status, 413)


class SubscriptionApiTests(ApiTests):
    """Majburiy obuna yoqilgan: Web App uni aylanib o'ta olmaydi. (Boshqa sinovlar ham qayta ishlaydi.)"""
    channels = ("@testkanal",)

    async def test_gate_and_check(self):
        self.session.subscribed = False
        resp = await self.get("/api/bootstrap")
        self.assertEqual(resp.status, 403)
        data = await resp.json()
        self.assertEqual((data["error"], data["channels"]), ("subscription", ["@testkanal"]))
        for path in ("/api/profile", "/api/leaderboard", "/api/lesson?topic_id=1"):
            self.assertEqual((await self.get(path)).status, 403, path)
        self.assertEqual((await self.post("/api/test/start", {"topic_id": 1})).status, 403)
        self.assertEqual((await (await self.post("/api/subscription", {})).json())["missing"], ["@testkanal"])
        self.session.subscribed = True
        self.assertEqual((await (await self.post("/api/subscription", {})).json())["missing"], [])
        self.assertEqual((await self.get("/api/bootstrap")).status, 200)

    async def test_admin_exempt_and_fail_open(self):
        self.session.subscribed = False
        self.assertEqual((await self.get("/api/bootstrap", user=ADMIN)).status, 200)
        self.session.member_error = True
        self.assertEqual((await self.get("/api/bootstrap")).status, 200)


if __name__ == "__main__":
    unittest.main()
