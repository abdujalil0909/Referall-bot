"""Servislar va ma'lumotlar bazasi sinovlari. Ishga tushirish:
    python -m unittest discover -s tests -t . -v
"""
import json
import os
import tempfile
import unittest

import aiosqlite

from database import CONTENT_PATH, get_db, init_db, seed_initial_content
from services import admin_service, content_service, test_service, user_service
from services.validators import clean_text, parse_field_value

ADMINS = frozenset({99})


class BaseCase(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "test.db")
        await init_db(self.db_path)
        await seed_initial_content(self.db_path)
        self._ctx = get_db(self.db_path)
        self.db = await self._ctx.__aenter__()

    async def asyncTearDown(self):
        await self._ctx.__aexit__(None, None, None)
        self.tmp.cleanup()

    async def play(self, user_id, topic_id, correct=True):
        """Testni to'liq o'ynaydi, finish natijasini qaytaradi."""
        attempt = await test_service.start_attempt(self.db, user_id, topic_id)
        while True:
            row = await test_service.get_attempt(self.db, attempt["id"], user_id)
            q = await test_service.get_current_question(self.db, row)
            if q is None:
                break
            right = q["correct_option"]
            option = right if correct else (right % 4) + 1
            res = await test_service.submit_answer(self.db, row, q["id"], option)
            self.assertIsNotNone(res)
        return await test_service.finish_attempt(self.db, attempt["id"], user_id)


class SeedAndSchemaTests(BaseCase):
    async def test_seed_content(self):
        topics = await content_service.list_topics(self.db)
        self.assertEqual(len(topics), 8)
        for t in topics:
            cur = await self.db.execute("SELECT COUNT(*) FROM questions WHERE topic_id=?", (t["id"],))
            self.assertEqual((await cur.fetchone())[0], 10, t["title"])
            self.assertEqual(len(await content_service.get_lessons(self.db, t["id"])), 1)

    async def test_seed_is_idempotent(self):
        self.assertFalse(await seed_initial_content(self.db_path))
        cur = await self.db.execute("SELECT COUNT(*) FROM topics")
        self.assertEqual((await cur.fetchone())[0], 8)

    async def test_content_file_is_valid(self):
        data = json.loads(CONTENT_PATH.read_text(encoding="utf-8"))
        for topic in data["topics"]:
            for q in topic["questions"]:
                self.assertEqual(len(q["options"]), 4)
                self.assertEqual(len(set(q["options"])), 4, q["text"])
                self.assertIn(q["correct"], (1, 2, 3, 4))
                self.assertTrue(q["explanation"])

    async def test_all_tables_exist(self):
        cur = await self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")
        names = {r[0] for r in await cur.fetchall()}
        for t in ("users", "topics", "lessons", "questions", "test_attempts", "test_answers"):
            self.assertIn(t, names)

    async def test_foreign_key_enforced(self):
        with self.assertRaises(aiosqlite.IntegrityError):
            await self.db.execute("INSERT INTO test_attempts(user_id, topic_id) VALUES (12345, 1)")

    async def test_check_constraint_enforced(self):
        await user_service.register_user(self.db, 1, "A", None)
        with self.assertRaises(aiosqlite.IntegrityError):
            await self.db.execute(
                "INSERT INTO questions(topic_id,text,option_1,option_2,option_3,option_4,correct_option,explanation)"
                " VALUES (1,'q','a','b','c','d',7,'e')")


class UserTests(BaseCase):
    async def test_register_and_update(self):
        await user_service.register_user(self.db, 1, "Abu", "abu")
        await user_service.register_user(self.db, 1, "Abu Yangi", None)
        user = await user_service.get_user(self.db, 1)
        self.assertEqual(user["full_name"], "Abu Yangi")
        self.assertEqual(user["tests_taken"], 0)
        self.assertEqual(await user_service.count_users(self.db), 1)
        self.assertIsNone(await user_service.get_user(self.db, 404))

    async def test_sql_injection_string_is_stored_as_data(self):
        evil = "x'); DROP TABLE users;--"
        await user_service.register_user(self.db, 5, evil, evil)
        self.assertEqual((await user_service.get_user(self.db, 5))["full_name"], evil)
        self.assertEqual(await user_service.count_users(self.db), 1)


class TestFlowTests(BaseCase):
    async def asyncSetUp(self):
        await super().asyncSetUp()
        for uid in (1, 2, 3):
            await user_service.register_user(self.db, uid, f"User{uid}", None)

    async def test_perfect_test_updates_stats(self):
        result = await self.play(1, 1)
        self.assertEqual((result["score"], result["total"], result["percent"]), (10, 10, 100))
        user = await user_service.get_user(self.db, 1)
        self.assertEqual((user["tests_taken"], user["total_score"], user["best_percent"]), (1, 10, 100))

    async def test_all_wrong_gives_zero(self):
        result = await self.play(1, 2, correct=False)
        self.assertEqual((result["score"], result["percent"]), (0, 0))

    async def test_finish_twice_counts_once(self):
        attempt = await test_service.start_attempt(self.db, 1, 1)
        await test_service.finish_attempt(self.db, attempt["id"], 1)
        await test_service.finish_attempt(self.db, attempt["id"], 1)
        self.assertEqual((await user_service.get_user(self.db, 1))["tests_taken"], 1)

    async def test_double_and_stale_answers_rejected(self):
        attempt = await test_service.start_attempt(self.db, 1, 1)
        row = await test_service.get_attempt(self.db, attempt["id"], 1)
        q = await test_service.get_current_question(self.db, row)
        self.assertIsNone(await test_service.submit_answer(self.db, row, q["id"] + 9999, 1))
        self.assertIsNone(await test_service.submit_answer(self.db, row, q["id"], 9))
        self.assertIsNotNone(await test_service.submit_answer(self.db, row, q["id"], 1))
        self.assertIsNone(await test_service.submit_answer(self.db, row, q["id"], 1))

    async def test_other_user_cannot_access_attempt(self):
        attempt = await test_service.start_attempt(self.db, 1, 1)
        self.assertIsNone(await test_service.get_attempt(self.db, attempt["id"], 2))
        self.assertIsNone(await test_service.finish_attempt(self.db, attempt["id"], 2))

    async def test_new_attempt_abandons_old(self):
        first = await test_service.start_attempt(self.db, 1, 1)
        await test_service.start_attempt(self.db, 1, 2)
        row = await test_service.get_attempt(self.db, first["id"], 1)
        self.assertEqual(row["status"], "abandoned")
        self.assertIsNone(await test_service.finish_attempt(self.db, first["id"], 1))

    async def test_deleted_question_mid_test(self):
        attempt = await test_service.start_attempt(self.db, 1, 1)
        row = await test_service.get_attempt(self.db, attempt["id"], 1)
        q = await test_service.get_current_question(self.db, row)
        await admin_service.delete_question(self.db, ADMINS, 99, q["id"])
        q2 = await test_service.get_current_question(self.db, row)
        self.assertNotEqual(q2["id"], q["id"])

    async def test_empty_topic_returns_none(self):
        await self.db.execute("INSERT INTO topics(title, position) VALUES ('Bo''sh', 99)")
        await self.db.commit()
        cur = await self.db.execute("SELECT id FROM topics WHERE title = 'Bo''sh'")
        topic_id = (await cur.fetchone())[0]
        self.assertIsNone(await test_service.start_attempt(self.db, 1, topic_id))


class ProfileAndLeaderboardTests(TestFlowTests):
    async def test_profile_stats(self):
        await self.play(1, 1)
        await self.play(1, 2, correct=False)
        stats = await user_service.get_profile_stats(self.db, 1)
        self.assertEqual(stats["average"], 50)
        self.assertEqual([m["title"] for m in stats["mastered"]], ["Kiberxavfsizlikka kirish"])
        self.assertEqual(len(stats["recent"]), 2)
        self.assertEqual(stats["user"]["tests_taken"], 2)

    async def test_leaderboard_order_and_tie_rule(self):
        await self.play(1, 1)                 # user1: 10 ball, 100%
        await self.play(2, 1)                 # user2: 10 ball, 100% (teng)
        await self.play(3, 1, correct=False)  # user3: 0 ball (reytingda yo'q)
        await self.db.execute("UPDATE users SET registered_at='2020-01-01 00:00:00' WHERE telegram_id=2")
        await self.db.commit()
        top = await user_service.get_leaderboard(self.db)
        self.assertEqual([r["full_name"] for r in top], ["User2", "User1"])  # erta ro'yxatdan o'tgan yuqorida
        self.assertEqual(await user_service.get_user_rank(self.db, 2), 1)
        self.assertEqual(await user_service.get_user_rank(self.db, 1), 2)
        self.assertIsNone(await user_service.get_user_rank(self.db, 3))

    async def test_leaderboard_limit_10(self):
        for uid in range(100, 115):
            await user_service.register_user(self.db, uid, f"U{uid}", None)
            await self.db.execute("UPDATE users SET total_score=? WHERE telegram_id=?", (uid, uid))
        await self.db.commit()
        top = await user_service.get_leaderboard(self.db)
        self.assertEqual(len(top), 10)
        self.assertEqual(top[0]["total_score"], 114)


class AdminServiceTests(BaseCase):
    async def test_non_admin_denied_everywhere(self):
        calls = [
            admin_service.get_bot_stats(self.db, ADMINS, 1),
            admin_service.add_lesson(self.db, ADMINS, 1, 1, "a", "b", "c"),
            admin_service.add_question(self.db, ADMINS, 1, 1, "q", list("abcd"), 1, "e"),
            admin_service.list_questions(self.db, ADMINS, 1, 1, 0),
            admin_service.get_question(self.db, ADMINS, 1, 1),
            admin_service.update_question_field(self.db, ADMINS, 1, 1, "text", "x"),
            admin_service.delete_question(self.db, ADMINS, 1, 1),
        ]
        for call in calls:
            with self.assertRaises(PermissionError):
                await call

    async def test_question_crud(self):
        qid = await admin_service.add_question(
            self.db, ADMINS, 99, 1, "Yangi savol?", ["a", "b", "c", "d"], 3, "Izoh")
        q = await admin_service.get_question(self.db, ADMINS, 99, qid)
        self.assertEqual((q["text"], q["correct_option"]), ("Yangi savol?", 3))
        self.assertTrue(await admin_service.update_question_field(self.db, ADMINS, 99, qid, "option_2", "yangi"))
        self.assertTrue(await admin_service.update_question_field(self.db, ADMINS, 99, qid, "correct_option", 4))
        q = await admin_service.get_question(self.db, ADMINS, 99, qid)
        self.assertEqual((q["option_2"], q["correct_option"]), ("yangi", 4))
        result = await admin_service.delete_question(self.db, ADMINS, 99, qid)
        self.assertEqual(result["remaining"], 10)
        self.assertIsNone(await admin_service.get_question(self.db, ADMINS, 99, qid))
        self.assertIsNone(await admin_service.delete_question(self.db, ADMINS, 99, qid))

    async def test_field_whitelist(self):
        with self.assertRaises(ValueError):
            await admin_service.update_question_field(self.db, ADMINS, 99, 1, "id = 5, text", "x")
        with self.assertRaises(ValueError):
            await admin_service.update_question_field(self.db, ADMINS, 99, 1, "topic_id", 2)

    async def test_add_question_validation(self):
        with self.assertRaises(ValueError):
            await admin_service.add_question(self.db, ADMINS, 99, 1, "q", ["a", "b"], 1, "e")
        with self.assertRaises(ValueError):
            await admin_service.add_question(self.db, ADMINS, 99, 1, "q", list("abcd"), 5, "e")

    async def test_add_lesson_and_pagination(self):
        await admin_service.add_lesson(self.db, ADMINS, 99, 1, "Yangi dars", "Misol", "1. Savol")
        self.assertEqual(len(await content_service.get_lessons(self.db, 1)), 2)
        page0, total = await admin_service.list_questions(self.db, ADMINS, 99, 1, 0)
        page1, _ = await admin_service.list_questions(self.db, ADMINS, 99, 1, 1)
        self.assertEqual((len(page0), len(page1), total), (5, 5, 10))
        self.assertTrue({q["id"] for q in page0}.isdisjoint({q["id"] for q in page1}))

    async def test_bot_stats(self):
        await user_service.register_user(self.db, 1, "A", None)
        stats = await admin_service.get_bot_stats(self.db, ADMINS, 99)
        self.assertEqual((stats["users"], stats["topics"], stats["questions"]), (1, 8, 80))


class ValidatorTests(unittest.TestCase):
    def test_clean_text(self):
        self.assertEqual(clean_text("  salom \x00 ", 10), "salom")
        self.assertIsNone(clean_text("   ", 10))
        self.assertIsNone(clean_text("x" * 11, 10))
        self.assertIsNone(clean_text(None, 10))

    def test_parse_field_value(self):
        self.assertEqual(parse_field_value("correct_option", " 3 "), 3)
        self.assertIsNone(parse_field_value("correct_option", "5"))
        self.assertIsNone(parse_field_value("correct_option", "abc"))
        self.assertIsNone(parse_field_value("id", "1"))
        self.assertIsNone(parse_field_value("option_1", "x" * 151))


if __name__ == "__main__":
    unittest.main()
