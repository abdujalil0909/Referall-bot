import os
import unittest
from unittest.mock import patch

import config


class ConfigTests(unittest.TestCase):
    def load(self, **env):
        with patch.dict(os.environ, env, clear=True):
            return config.load_settings()

    def test_valid(self):
        s = self.load(BOT_TOKEN="x", ADMIN_IDS="1, 2", REQUIRED_CHANNELS="@kanal_bir, @kanal_ikki")
        self.assertEqual(s.admin_ids, {1, 2})
        self.assertEqual(s.required_channels, ("@kanal_bir", "@kanal_ikki"))
        self.assertEqual(s.db_path, "cyberstart.db")

    def test_defaults(self):
        s = self.load(BOT_TOKEN="x")
        self.assertEqual((s.admin_ids, s.required_channels), (frozenset(), ()))

    def test_missing_token(self):
        with self.assertRaises(RuntimeError):
            self.load(BOT_TOKEN="  ")

    def test_bad_admin_ids(self):
        with self.assertRaises(RuntimeError):
            self.load(BOT_TOKEN="x", ADMIN_IDS="12,abc")

    def test_bad_channels(self):
        for bad in ("kanal", "@ab", "-100123", "@kanal nomi", "https://t.me/kanal"):
            with self.assertRaises(RuntimeError, msg=bad):
                self.load(BOT_TOKEN="x", REQUIRED_CHANNELS=bad)


if __name__ == "__main__":
    unittest.main()
