"""Bot oqimi sinovi: haqiqiy Dispatcher, soxta Telegram sessiyasi (tarmoqsiz)."""
import os
import tempfile
import unittest
from datetime import datetime

from aiogram import Bot
from aiogram.client.session.base import BaseSession
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import AnswerCallbackQuery, GetChatMember, GetMe
from aiogram.types import ChatMemberLeft, ChatMemberMember, Message, User

from bot import RedactingFormatter, build_dispatcher, check_channels
from handlers import admin, leaderboard, learning, profile, start, tests
from config import Settings
from database import get_db, init_db, seed_initial_content
from services import test_service

USER, ADMIN = 1001, 2002
TOKEN = "123456789:" + "A" * 35


class FakeSession(BaseSession):
    """Telegramga so'rov yubormaydi, chaqiruvlarni yig'ib boradi."""

    def __init__(self):
        super().__init__()
        self.calls = []
        self.subscribed = True      # get_chat_member natijasi
        self.member_error = False   # True bo'lsa, get_chat_member xato beradi

    async def close(self):
        pass

    async def stream_content(self, *args, **kwargs):
        yield b""

    async def make_request(self, bot, method, timeout=None):
        self.calls.append(method)
        if isinstance(method, GetMe):
            return User(id=777, is_bot=True, first_name="bot", username="cs_bot")
        if isinstance(method, GetChatMember):
            if self.member_error:
                raise TelegramBadRequest(method=method, message="chat not found")
            user = User(id=method.user_id, is_bot=False, first_name="x")
            return ChatMemberMember(user=user) if self.subscribed else ChatMemberLeft(user=user)
        if isinstance(method, AnswerCallbackQuery):
            return True
        return Message.model_validate(
            {"message_id": len(self.calls), "date": 0, "chat": {"id": 1, "type": "private"}, "text": "x"})


class FlowTests(unittest.IsolatedAsyncioTestCase):
    channels: tuple = ()
    webapp_url = None

    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "flow.db")
        await init_db(self.db_path)
        await seed_initial_content(self.db_path)
        self.settings = Settings(TOKEN, frozenset({ADMIN}), self.db_path, self.channels, self.webapp_url)
        self.session = FakeSession()
        self.bot = Bot(TOKEN, session=self.session)
        # Routerlar modul darajasida bitta; har bir sinov uchun yangi Dispatcherga ulash uchun uziladi
        for module in (start, learning, tests, profile, leaderboard, admin):
            module.router._parent_router = None
        start.fallback_router._parent_router = None
        self.dp = build_dispatcher(self.settings)
        self.uid = 0

    async def asyncTearDown(self):
        self.tmp.cleanup()

    def _user(self, user_id):
        return {"id": user_id, "is_bot": False, "first_name": "Test", "username": f"u{user_id}"}

    def _message(self, user_id, text, command=False):
        msg = {"message_id": 1, "date": int(datetime.now().timestamp()),
               "chat": {"id": user_id, "type": "private"}, "from": self._user(user_id), "text": text}
        if command:
            msg["entities"] = [{"type": "bot_command", "offset": 0, "length": len(text.split()[0])}]
        return msg

    async def send(self, user_id, text, command=False):
        self.uid += 1
        self.session.calls.clear()
        await self.dp.feed_raw_update(self.bot, {"update_id": self.uid, "message": self._message(user_id, text, command)})
        return list(self.session.calls)

    async def click(self, user_id, data):
        self.uid += 1
        self.session.calls.clear()
        update = {"update_id": self.uid, "callback_query": {
            "id": str(self.uid), "from": self._user(user_id), "chat_instance": "x", "data": data,
            "message": self._message(user_id, "old")}}
        await self.dp.feed_raw_update(self.bot, update)
        return list(self.session.calls)

    @staticmethod
    def texts(calls):
        import re
        joined = " ".join(getattr(c, "text", "") or "" for c in calls)
        return re.sub(r"</?[a-z]+>", "", joined)  # HTML teglarsiz matn

    @staticmethod
    def buttons(calls):
        out = []
        for c in calls:
            markup = getattr(c, "reply_markup", None)
            for row in getattr(markup, "inline_keyboard", []) or []:
                out += [b.callback_data for b in row]
        return out

    async def current_question(self, user_id):
        async with get_db(self.db_path) as db:
            cur = await db.execute(
                "SELECT * FROM test_attempts WHERE user_id=? AND status='in_progress' ORDER BY id DESC LIMIT 1",
                (user_id,))
            attempt = dict(await cur.fetchone())
            return attempt, await test_service.get_current_question(db, attempt)

    async def test_start_and_menu(self):
        calls = await self.send(USER, "/start", command=True)
        self.assertIn("CyberStart", self.texts(calls))
        self.assertIn("ReplyKeyboardMarkup", type(calls[-1].reply_markup).__name__)
        self.assertIn("CyberStart haqida", self.texts(await self.send(USER, "ℹ️ Loyiha haqida")))
        self.assertIn("O'rganish", self.texts(await self.send(USER, "🛡️ O'rganish")))

    async def test_learning(self):
        calls = await self.send(USER, "🛡️ O'rganish")
        self.assertIn("lt:1", self.buttons(calls))
        calls = await self.click(USER, "lt:1")
        self.assertIn("Amaliy misol", self.texts(calls))
        self.assertIn("tt:1", self.buttons(calls))

    async def test_full_test_and_results(self):
        await self.send(USER, "/start", command=True)
        calls = await self.click(USER, "tt:1")
        self.assertIn("Savol 1/10", self.texts(calls))
        for number in range(1, 11):
            attempt, question = await self.current_question(USER)
            self.assertEqual(question["number"], number)
            wrong = number == 10  # oxirgisi noto'g'ri
            option = (question["correct_option"] % 4) + 1 if wrong else question["correct_option"]
            data = f"a:{attempt['id']}:{question['id']}:{option}"
            calls = await self.click(USER, data)
            text = self.texts(calls)
            self.assertIn("Noto'g'ri" if wrong else "To'g'ri", text)
            self.assertIn("💡", text)
            # takroriy bosish rad etiladi
            again = await self.click(USER, data)
            self.assertTrue(any(isinstance(c, AnswerCallbackQuery) and c.show_alert for c in again))
            calls = await self.click(USER, f"n:{attempt['id']}")
        self.assertIn("Test yakunlandi", self.texts(calls))
        self.assertIn("9/10", self.texts(calls))
        self.assertIn("90%", self.texts(calls))
        results = self.texts(await self.send(USER, "📊 Mening natijalarim"))
        self.assertIn("Ishlangan testlar: 1", results)
        self.assertIn("To'plangan ball: 9", results)
        board = self.texts(await self.send(USER, "🏆 Reyting"))
        self.assertIn("Sizning o'rningiz: 1", board)
        self.assertNotIn(str(USER), board)

    async def test_other_user_cannot_answer_my_test(self):
        await self.send(USER, "/start", command=True)
        await self.click(USER, "tt:1")
        attempt, question = await self.current_question(USER)
        await self.send(USER + 1, "/start", command=True)
        calls = await self.click(USER + 1, f"a:{attempt['id']}:{question['id']}:1")
        self.assertTrue(any(isinstance(c, AnswerCallbackQuery) and c.show_alert for c in calls))
        async with get_db(self.db_path) as db:
            cur = await db.execute("SELECT COUNT(*) FROM test_answers")
            self.assertEqual((await cur.fetchone())[0], 0)

    async def test_non_admin_blocked(self):
        self.assertIn("faqat administratorlar", self.texts(await self.send(USER, "/admin", command=True)))
        calls = await self.click(USER, "adm:users")
        self.assertTrue(any(isinstance(c, AnswerCallbackQuery) and c.show_alert for c in calls))
        calls = await self.click(USER, "adm:qdy:1")
        self.assertTrue(any(isinstance(c, AnswerCallbackQuery) and c.show_alert for c in calls))
        async with get_db(self.db_path) as db:
            cur = await db.execute("SELECT COUNT(*) FROM questions")
            self.assertEqual((await cur.fetchone())[0], 80)

    async def test_admin_add_edit_delete_question(self):
        self.assertIn("Admin paneli", self.texts(await self.send(ADMIN, "/admin", command=True)))
        self.assertIn("Foydalanuvchilar soni", self.texts(await self.click(ADMIN, "adm:users")))
        self.assertIn("Bot statistikasi", self.texts(await self.click(ADMIN, "adm:stats")))
        await self.click(ADMIN, "adm:aqt:1")
        await self.send(ADMIN, "Yangi savol matni?")
        await self.send(ADMIN, "bir\niki\nuch\nto'rt")
        calls = await self.click(ADMIN, "adm:qc:2")
        self.assertIn("izoh", self.texts(calls).lower())
        self.assertIn("Savol qo'shildi", self.texts(await self.send(ADMIN, "Izoh matni")))
        async with get_db(self.db_path) as db:
            cur = await db.execute("SELECT id, correct_option, option_4 FROM questions WHERE text='Yangi savol matni?'")
            row = await cur.fetchone()
            self.assertEqual((row["correct_option"], row["option_4"]), (2, "to'rt"))
            qid = row["id"]
        # tahrirlash: noto'g'ri qiymat rad etiladi, to'g'risi qabul qilinadi
        await self.click(ADMIN, f"adm:qe:{qid}:correct_option")
        self.assertIn("noto'g'ri", self.texts(await self.send(ADMIN, "9")).lower())
        self.assertIn("Yangilandi", self.texts(await self.send(ADMIN, "4")))
        # o'chirish
        self.assertIn("o'chirilsinmi", self.texts(await self.click(ADMIN, f"adm:qd:{qid}")))
        self.assertIn("o'chirildi", self.texts(await self.click(ADMIN, f"adm:qdy:{qid}")))
        async with get_db(self.db_path) as db:
            cur = await db.execute("SELECT COUNT(*) FROM questions WHERE id=?", (qid,))
            self.assertEqual((await cur.fetchone())[0], 0)

    async def test_admin_add_lesson_and_menu_button_exits_state(self):
        await self.click(ADMIN, "adm:alt:1")
        await self.send(ADMIN, "Tushuntirish")
        await self.send(ADMIN, "Misol")
        self.assertIn("Dars qo'shildi", self.texts(await self.send(ADMIN, "1. Savol")))
        # holat ichida menyu tugmasi holatni tozalaydi
        await self.click(ADMIN, "adm:aqt:1")
        calls = await self.send(ADMIN, "📝 Test ishlash")
        self.assertIn("Test ishlash", self.texts(calls))
        calls = await self.send(ADMIN, "tasodifiy matn")
        self.assertIn("Menyudan", self.texts(calls))

    async def test_unknown_text(self):
        self.assertIn("Menyudan", self.texts(await self.send(USER, "salom?")))

    def test_token_redacted_in_logs(self):
        import logging
        fmt = RedactingFormatter(TOKEN)
        record = logging.LogRecord("x", logging.ERROR, __file__, 1, f"url https://api/bot{TOKEN}/send", None, None)
        self.assertNotIn(TOKEN, fmt.format(record))


class SubscriptionTests(FlowTests):
    """Majburiy obuna yoqilgan holat. (FlowTests sinovlari ham obunali holatda qayta ishlaydi.)"""
    channels = ("@testkanal",)

    def alert(self, calls):
        return any(isinstance(c, AnswerCallbackQuery) and c.show_alert for c in calls)

    async def test_unsubscribed_is_blocked(self):
        self.session.subscribed = False
        calls = await self.send(USER, "/start", command=True)
        self.assertIn("obuna bo'ling", self.texts(calls))
        self.assertNotIn("xush kelibsiz", self.texts(calls))
        urls = [b.url for c in calls for row in getattr(getattr(c, "reply_markup", None), "inline_keyboard", []) for b in row if b.url]
        self.assertEqual(urls, ["https://t.me/testkanal"])
        self.assertIn("sub:check", self.buttons(calls))
        # menyu tugmalari ham, test tugmalari ham bloklanadi
        self.assertIn("obuna bo'ling", self.texts(await self.send(USER, "🏆 Reyting")))
        calls = await self.click(USER, "tt:1")
        self.assertTrue(self.alert(calls))
        async with get_db(self.db_path) as db:
            cur = await db.execute("SELECT COUNT(*) FROM test_attempts")
            self.assertEqual((await cur.fetchone())[0], 0)

    async def test_check_button_flow(self):
        self.session.subscribed = False
        await self.send(USER, "/start", command=True)
        calls = await self.click(USER, "sub:check")
        self.assertTrue(self.alert(calls))
        self.session.subscribed = True
        calls = await self.click(USER, "sub:check")
        self.assertIn("Obuna tasdiqlandi", self.texts(calls))
        self.assertIn("O'rganish", self.texts(await self.send(USER, "🛡️ O'rganish")))

    async def test_admin_exempt(self):
        self.session.subscribed = False
        self.assertIn("Admin paneli", self.texts(await self.send(ADMIN, "/admin", command=True)))

    async def test_fail_open_when_channel_unreachable(self):
        self.session.member_error = True
        self.assertIn("xush kelibsiz", self.texts(await self.send(USER, "/start", command=True)))

    async def test_startup_warns_when_bot_not_admin(self):
        # soxta sessiyada bot oddiy a'zo qaytadi, ya'ni admin emas
        with self.assertLogs("cyberstart", "WARNING") as logs:
            await check_channels(self.bot, self.settings)
        self.assertIn("admin emas", logs.output[0])

    async def test_startup_warns_when_channel_unreachable(self):
        self.session.member_error = True
        with self.assertLogs("cyberstart", "WARNING") as logs:
            await check_channels(self.bot, self.settings)
        self.assertIn("tekshirilmadi", logs.output[0])

    async def test_unsubscribe_after_cache_expiry(self):
        await self.send(USER, "/start", command=True)          # a'zo, keshga tushdi
        self.session.subscribed = False
        self.dp.workflow_data["subscription"]._ok_until.clear()  # kesh muddati tugadi
        self.assertIn("obuna bo'ling", self.texts(await self.send(USER, "🏆 Reyting")))


class WebAppButtonTests(FlowTests):
    """Web App yoqilgan: menyuda tugma bor, lekin initData bo'sh qolmasligi uchun u inline orqali ochiladi."""
    webapp_url = "https://example.com/app"

    async def test_menu_button_is_plain_and_launch_is_inline(self):
        calls = await self.send(USER, "/start", command=True)
        keys = [b for row in calls[-1].reply_markup.keyboard for b in row]
        self.assertIn("🌐 Web App", [b.text for b in keys])
        # reply-klaviaturadagi web_app tugmasida Telegram initData bermaydi: tugma oddiy bo'lishi shart
        self.assertTrue(all(b.web_app is None for b in keys))
        for text, command in (("🌐 Web App", False), ("/app", True)):
            calls = await self.send(USER, text, command=command)
            button = calls[-1].reply_markup.inline_keyboard[0][0]
            self.assertEqual(button.web_app.url, "https://example.com/app")


class WebAppDisabledTests(FlowTests):
    async def test_no_button_and_command_explains(self):
        calls = await self.send(USER, "/start", command=True)
        labels = [b.text for row in calls[-1].reply_markup.keyboard for b in row]
        self.assertNotIn("🌐 Web App", labels)
        self.assertIn("sozlanmagan", self.texts(await self.send(USER, "/app", command=True)))


if __name__ == "__main__":
    unittest.main()
