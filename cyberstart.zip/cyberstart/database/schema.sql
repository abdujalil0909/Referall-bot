PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
    telegram_id INTEGER PRIMARY KEY,
    full_name TEXT NOT NULL,
    username TEXT,
    registered_at TEXT NOT NULL DEFAULT (datetime('now')),
    tests_taken INTEGER NOT NULL DEFAULT 0 CHECK (tests_taken >= 0),
    total_score INTEGER NOT NULL DEFAULT 0 CHECK (total_score >= 0),
    best_percent INTEGER NOT NULL DEFAULT 0 CHECK (best_percent BETWEEN 0 AND 100)
);

CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL UNIQUE,
    position INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS lessons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
    summary TEXT NOT NULL,
    practical_example TEXT NOT NULL,
    review_questions TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
    text TEXT NOT NULL,
    option_1 TEXT NOT NULL,
    option_2 TEXT NOT NULL,
    option_3 TEXT NOT NULL,
    option_4 TEXT NOT NULL,
    correct_option INTEGER NOT NULL CHECK (correct_option BETWEEN 1 AND 4),
    explanation TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS test_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(telegram_id) ON DELETE CASCADE,
    topic_id INTEGER NOT NULL REFERENCES topics(id),
    started_at TEXT NOT NULL DEFAULT (datetime('now')),
    finished_at TEXT,
    score INTEGER NOT NULL DEFAULT 0 CHECK (score >= 0),
    total INTEGER NOT NULL DEFAULT 10 CHECK (total > 0),
    question_ids TEXT NOT NULL DEFAULT '[]',
    status TEXT NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'finished', 'abandoned'))
);

CREATE TABLE IF NOT EXISTS test_answers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    attempt_id INTEGER NOT NULL REFERENCES test_attempts(id) ON DELETE CASCADE,
    question_id INTEGER REFERENCES questions(id) ON DELETE SET NULL,
    chosen_option INTEGER NOT NULL CHECK (chosen_option BETWEEN 1 AND 4),
    is_correct INTEGER NOT NULL CHECK (is_correct IN (0, 1)),
    UNIQUE (attempt_id, question_id)
);

CREATE INDEX IF NOT EXISTS idx_lessons_topic ON lessons(topic_id);
CREATE INDEX IF NOT EXISTS idx_questions_topic ON questions(topic_id);
CREATE INDEX IF NOT EXISTS idx_attempts_user ON test_attempts(user_id, status);
CREATE INDEX IF NOT EXISTS idx_answers_attempt ON test_answers(attempt_id);
CREATE INDEX IF NOT EXISTS idx_users_rank ON users(total_score DESC, best_percent DESC, registered_at);
